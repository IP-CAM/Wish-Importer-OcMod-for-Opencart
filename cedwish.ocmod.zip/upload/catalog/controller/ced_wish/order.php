<?php
class ControllerCedWishOrder extends Controller {
	private $error = array();

	public function fetchOrder() {

		$this->load->library('cedwish');
		$this->load->language('ced_wish/order');
		//$this->load->model('ced_wish/order');
		$cedwish = Cedwish::getInstance($this->registry); 
        $createdStartDate = date('Y-m-d',strtotime("-1 days"));
        $order = array('from' => $createdStartDate);
		$response = $cedwish->fetchOrders($order);

		if(isset($response['success']) && $response['success']) {
			if(count($response['message']))
			$this->session->data['success'] = 'Order Imported Successfully.';
			else 
			$this->session->data['success'] = 'No new Orders Found.';	
		} else {
			$this->error[] = $response['message'];
		}
		$this->getList();
	}

}

?>