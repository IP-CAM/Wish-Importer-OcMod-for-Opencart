<?php
class ControllerCedWishProduct extends Controller {
    private $error = array();


    public function fetchStatus()
    {
        $this->load->library('cedwish');
        $cedwish = Cedwish::getInstance($this->registry);
        $product_ids = array();
        $json = array();
        if (isset($this->request->post['selected'])) {
            $product_ids = (array)$this->request->post['selected'];
            $response = $cedwish->fetchStock($product_ids);

            if (isset($response['success']) && $response['success']) {

                if(is_array($response['message']) && !empty($response['message'])){
                    $message = $response['message']['0']['error'];
                    $json['message'] = $message;
                    $json['success'] = false;
                }
                else{
                    $json['message'] = 'Product(s) Status Fetched Successfully.';
                    $json['success'] = true;
                }

            } else {
                $json['success'] = false;
                $json['message'] = ($response['message'])?$response['message']:'No product to fetch.';
            }
        } else {
            $json['success'] = false;
            $json['message'] = 'No Category Mapped yet';
        }

        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }

}
?>