<?php

class ControllerCedWishSuccess extends Controller
{ 
	public function index(){

		$this->load->language('ced_wish/success');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('ced_wish/success');
		$this->load->library('cedwish');
		$cedwish = Cedwish::getInstance($this->registry);

		if(!empty($this->request->get['code'])){
			$data['code'] = $this->request->get['code'];

			$this->model_ced_wish_success->editSetting('ced_wish', 'ced_wish_generate_code' , $this->request->get['code']);
		    $accessToken = $cedwish->getAccessToken($this->request->get['code']);
		}
		
		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/ced_wish/success.tpl')) {
			$this->response->setOutput($this->load->view($this->config->get('config_template') . '/template/ced_wish/success.tpl', $data));
		} else {
			$this->response->setOutput($this->load->view('default/template/ced_wish/success.tpl', $data));
		}
	}
}
?>