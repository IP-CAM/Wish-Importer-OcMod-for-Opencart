<?php
// Heading
$_['heading_title']              = 'Wish Failed Orders';
$_['button_history_add']         = 'Create Shipment';
// Text
$_['text_success']               = 'Success: You have modified orders!';
$_['text_list']                  = 'Order List';
$_['text_order_detail']          = 'Order Details';
$_['text_missing']               = 'Missing Orders';

// Column
$_['column_order_id']            = 'Order ID';
$_['column_customer']            = 'Customer';
$_['column_status']              = 'Status';
$_['column_total']               = 'Total';
$_['column_wish_order_id']       = 'Wish Order ID';
$_['column_wish_status']         = 'Wish Status';
$_['column_date_added']          = 'Date Added';
$_['column_action']              = 'Action';

$_['column_skuId']               = 'SKU ID';
$_['column_wishProductId']       = 'Wish Product ID';
$_['column_productTitle']        = 'Product Title';
$_['column_orderTotal']          = 'Total Cost';
$_['column_quantity']            = 'Total No. Of Items';

$_['column_tracking_provider']   = 'Tracking Provider';
$_['column_tracking_number']     = 'Tracking Number';
$_['column_ship_note']           = 'Ship Note';

// Entry
$_['entry_customer_id']          = 'Customer ID';
$_['entry_orderId']              = 'Order ID';
$_['entry_order_date']           = 'Order Date';
$_['entry_wish_status']          = 'Wish Status';
$_['entry_language_code']        = 'Language Code';
$_['entry_shipping_method']      = 'Shipping Method';
$_['entry_cost']                 = 'Cost';
$_['entry_shippingCost']         = 'Shipping Cost';

$_['entry_shipping_firstname']   = 'Shipping Firstname';
$_['entry_shipping_lastname']    = 'Shipping Lastname';
$_['entry_shipping_address_1']   = 'Shipping Address';
$_['entry_shipping_city']        = 'Shipping City';
$_['entry_shipping_postcode']    = 'Shipping Postal Code';
$_['entry_shipping_iso_code_3']  = 'Shipping ISO Code';
$_['entry_telephone']            = 'Shipping Telephone No.';

// Error
$_['error_warning']              = 'Warning: Please check the form carefully for errors!';
$_['error_permission']           = 'Warning: You do not have permission to modify orders!';
$_['error_action']               = 'Warning: Could not complete this action!';
$_['error_filetype']			 = 'Invalid file type!';