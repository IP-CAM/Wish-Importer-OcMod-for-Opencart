<?php
// Heading
$_['heading_title']              = 'Failed Order';

// Text
$_['text_success']               = 'Success: You have modified orders!';
$_['text_no_results']            = 'No result found !';
$_['text_ced_wish']              = 'Ced Wish';

// Error Order
$_['text_error_list']            = 'Failed Order List';

// Column
$_['column_sku']                 = 'SKU ID';
$_['column_wish_order_id']       = 'Order ID';
$_['column_reason']              = 'Reason';
$_['column_action']              = 'Action';

// Error
$_['error_warning']              = 'Warning: Please check the form carefully for errors!';
$_['error_permission']           = 'Warning: You do not have permission to modify orders!';
$_['error_action']               = 'Warning: Could not complete this action!';

?>