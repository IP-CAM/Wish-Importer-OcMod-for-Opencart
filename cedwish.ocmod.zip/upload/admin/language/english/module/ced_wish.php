<?php
// Heading
$_['heading_title']                 = 'Wish Setting';

// Text
$_['text_module']                   = 'Modules';
$_['text_success']                  = 'Success: You have modified CED Wish module!';
$_['text_edit']                     = 'Edit Wish Setting';

//Tabs
$_['tab_general']                   = 'General';
$_['tab_wish_product']              = 'Product Setting';
$_['tab_wish_order']                = 'Order Setting';
$_['tab_wish_cron']                 = 'Cron Setting';
// $_['tab_wish_chunk']                = 'Chunk (Batch) Setting';

// General Tab
$_['entry_status']                   = 'Status';
$_['entry_api_mode']                 = 'API Mode';
// $_['entry_sandbox_client_id']        = 'Sandbox Client ID';
// $_['entry_sandbox_client_secret']    = 'Sandbox Client Secret';
// $_['entry_production_client_id']     = 'Client ID';
// $_['entry_production_client_secret'] = 'Client Secret';
$_['entry_redirect_uri']             = 'Redirect URI';
$_['button_generate']                = 'Generate Code'; 
$_['entry_generate_code']            = 'Code';
$_['button_validate']                = 'Validate Token';
$_['entry_access_token']             = 'Access Token';
$_['button_refresh']                 = 'Refresh Token';
$_['entry_enable_logging']           = 'Enable Logging';
$_['entry_api_mode_url']             = 'API URL';

// Wish Product Settings Tab
$_['entry_product_price']            = 'Product Price';
$_['entry_product_price_fixed']      = 'Modify By Fixed Price';
$_['entry_product_price_percentage'] = 'Modify By Percentage';
$_['entry_default_tags']             = 'Default Tags';
$_['entry_default_shipping']         = 'Default Shipping';
$_['entry_auto_update_product']      = 'Auto Update Product';

// Wish Order Settings Tab
// $_['entry_order_id_prefix']          = 'Order ID Prefix';
// $_['entry_order_notification']       = 'Allow Order Notification';
$_['entry_order_noti_email']         = 'Order Notification Email';
$_['entry_default_customer_email']   = 'Default Customer Email';
$_['entry_accept_order']             = 'Auto Accept Order';
$_['entry_cancel_order']             = 'Auto Cancel Order';

// Wish Cron Settings Tab
$_['entry_order_cron']               = 'Order Cron';
$_['entry_order_cron_time']          = 'Order Cron Time';
$_['entry_inventory_cron']           = 'Inventory Cron';
$_['entry_inventory_cron_time']      = 'Inventory Cron Time';

$_['ced_wish_order_cron']               = HTTPS_CATALOG . 'index.php?route=ced_wish/order/fetchOrder';;
$_['ced_wish_order_cron_time']          = '30 mins';
$_['ced_wish_inventory_cron']           = HTTPS_CATALOG . 'index.php?route=ced_wish/product/fetchStatus';
$_['ced_wish_inventory_cron_time']      = 'Once a day';

// Wish Chunk Settings Tab
// $_['entry_validate_chunk_size']      = 'Product Validation Chunk Size';
// $_['entry_upload_chunk']             = 'Product Upload Chunk';
// $_['entry_eds_chunk']                = 'Product Enable/Disable/Sync Chunk';

// Error
$_['error_permission']               = 'Warning: You do not have permission to modify CED Wish module!';
$_['error_code']                     = 'Please Fill Client ID and Client Secret';

//API URL
$_['api_url']                        = 'API Url';
$_['ced_wish_api_url']               = 'https://merchant.wish.com/api/v2/';