<?php
class ModelModuleCedwishCategory extends Model {

    public function install() {

        /*-------Create Tables--------*/

        //Product Cron
        $this->db->query("
				CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedwish_products_cron` (
    			`id` int(15) NOT NULL AUTO_INCREMENT,
  				`inventory_chunk` longtext NULL,
  				`type` text NULL,
   				PRIMARY KEY  (`id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");

        //Country Currency
        $this->db->query("
				CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedwish_country_currency` (
    			  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `country` text NULL,
				  `country_code` text NULL,
				  `language` text NULL,
				  `currency_code` text NULL,
				  `eu_member` text NULL,
 				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");

        //Order
        $this->db->query("
				CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedwish_order` (
    			  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `store_order_id` int(11) NULL,
				  `wish_order_id` text NULL,
				  `wish_product_id` text NULL,
				  `variant_id` text NULL,
				  `sku` text NULL,
				  `wish_status` text NULL,
				  `message` text NULL,
				  `order_place_date` datetime NULL,
				  `product_image_url` text NULL,
				  `shipping_detail` longtext NULL,
				  `order_data` longtext NULL,
 				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");

        //Order Error
        $this->db->query("
				CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedwish_order_error` (
    			  `id` int(11) NOT NULL AUTO_INCREMENT,
    			  `store_order_id` int(11) NULL,
				  `sku` text NULL,
				  `wish_order_id` text NULL,
				  `order_data` longtext NULL,
				  `reason` text NULL,
				  `cancel_qty` int(10),
 				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");

        //System Default
        $this->db->query("
				CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedwish_system_default` (
    			  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `name` text NULL,
				  `field_name` text NULL,
 				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");

        //Mapping Details
        $this->db->query("
				CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedwish_mapping_details` (
    			  `mapped_id` int(11) NOT NULL AUTO_INCREMENT,
    			  `CategoryName` text NULL,
    			  `status` int(11),
				  `category` text NULL,
				  `manufacturer` text NULL,
				  `product_store` text NULL,
				  `storeLanguage` text NULL,
				  `attribute` text NULL,
				  `variant_attribute` text NULL,
				  `default_attribute` text NULL,
 				  PRIMARY KEY  (`mapped_id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");

        //Category Product Mapping
        $this->db->query("
				CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedwish_product_variations` (
    			  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `profile_id` int(11) NULL,
				  `product_id` int(11) NULL,
				  `sku` text NULL,
				  `error_message` text NULL,
				  `wish_product_id` text NULL,
				  `wish_status` text NULL,
				  `created_on` datetime  DEFAULT CURRENT_TIMESTAMP,
 				  PRIMARY KEY  (`id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");

        //Category Product Attribute Combinations
        $this->db->query("
				CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedwish_product_attribute_combination` (
    			  `combination_id` int(11) NOT NULL AUTO_INCREMENT,
    			  `product_id` int(11) NULL,
				  `profile_id` int(11) NULL,
				  `SkuId` text NULL,
				  `combination` text NULL,
 				  PRIMARY KEY  (`combination_id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");

        //Job Status
        $this->db->query("
				CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedwish_job_status` (
    			  `job_status_id` int(11) NOT NULL AUTO_INCREMENT,
    			  `parent_sku` text NULL,
				  `job_id` text NULL,
				  `success_url` text NULL,
				  `failure_url` text NULL,
				  `merchant_id` text NULL,
				  `uploader_id` text NULL,
				  `data` longtext NULL,
				  `failure_data` longtext NULL,
 				  PRIMARY KEY  (`job_status_id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");

        //Product Response
        $this->db->query("
				CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedwish_product_response` (
    			  `product_response_id` int(11) NOT NULL AUTO_INCREMENT,
    			  `product_id` int(11) NULL,
				  `wish_product_id` text NULL,
				  `review_status` text NULL,
				  `variant_id` text NULL,
				  `parent_sku` text NULL,
				  `sku` text NULL,
				  `job_id` text NULL,
				  `data` longtext NULL,
 				  PRIMARY KEY  (`product_response_id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");

        //Variant Response
        $this->db->query("
				CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "cedwish_variant_response` (
    			  `variant_response_id` int(11) NOT NULL AUTO_INCREMENT,
    			  `product_id` int(11) NULL,
				  `profile_id` int(11) NULL,
				  `parent_sku` text NULL,
				  `sku` text NULL,
				  `variant_id` text NULL,
				  `variant_status` text NULL,
				  `inventory` int(11) NULL,
				  `data` longtext NULL,
 				  PRIMARY KEY  (`variant_response_id`)
				) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
			");


        /*--------------Country Currency----------------*/

        $sql[] = "INSERT INTO `" . DB_PREFIX . "cedwish_country_currency` (`id`, `country`, `country_code`, `language`, `currency_code`, `eu_member`) VALUES
(1, 'United Kingdom', 'GB', 'en', 'GBP', 'Yes'),
(2, 'Republic of Ireland', 'IE', 'en', 'EUR', 'Yes'),
(3, 'France', 'FR', 'fr', 'EUR', 'Yes'),
(4, 'France', 'FR', 'en', 'EUR', 'Yes'),
(5, 'Germany', 'DE', 'de', 'EUR', 'Yes'),
(6, 'Germany', 'DE', 'en', 'EUR', 'Yes'),
(7, 'Spain', 'ES', 'es', 'EUR', 'Yes'),
(8, 'Spain', 'ES', 'en', 'EUR', 'Yes'),
(9, 'Portugal', 'PT', 'en', 'EUR', 'Yes'),
(10, 'Portugal', 'PT', 'pt', 'EUR', 'Yes'),
(11, 'Belgium', 'BE', 'de', 'EUR', 'Yes'),
(12, 'Belgium', 'BE', 'fr', 'EUR', 'Yes'),
(13, 'Belgium', 'BE', 'nl', 'EUR', 'Yes'),
(14, 'Belgium', 'BE', 'en', 'EUR', 'Yes'),
(15, 'Netherlands', 'NL', 'en', 'EUR', 'Yes'),
(16, 'Netherlands', 'NL', 'nl', 'EUR', 'Yes'),
(17, 'Luxembourg', 'LU', 'en', 'EUR', 'Yes'),
(18, 'Luxembourg', 'LU', 'de', 'EUR', 'Yes'),
(19, 'Luxembourg', 'LU', 'fr', 'EUR', 'Yes'),
(20, 'Poland', 'PL', 'en', 'PLN', 'Yes'),
(21, 'Poland', 'PL', 'pl', 'PLN', 'Yes'),
(22, 'Austria', 'AT', 'en', 'EUR', 'Yes'),
(23, 'Austria', 'AT', 'de', 'EUR', 'Yes'),
(24, 'Italy', 'IT', 'en', 'EUR', 'Yes'),
(25, 'Italy', 'IT', 'it', 'EUR', 'Yes'),
(26, 'Denmark', 'DK', 'da', 'DKK', 'Yes'),
(27, 'Denmark', 'DK', 'en', 'DKK', 'Yes'),
(28, 'Sweden', 'SE', 'sv', 'SEK', 'Yes'),
(29, 'Sweden', 'SE', 'fi	', 'SEK', 'Yes'),
(30, 'Sweden', 'SE', 'en', 'SEK', 'Yes'),
(31, 'Finland', 'FI', 'fi', 'EUR', 'Yes'),
(32, 'Finland', 'FI', 'sv	', 'EUR', 'Yes'),
(33, 'Finland', 'FI', 'en', 'EUR', 'Yes'),
(34, 'Norway', 'NO', 'no', 'NOK', 'No'),
(35, 'Norway', 'NO', 'en', 'NOK', 'No'),
(36, 'Switzerland', 'CH', 'de', 'CHF', 'No'),
(37, 'Switzerland', 'CH', 'it', 'CHF', 'No'),
(38, 'Switzerland', 'CH', 'de', 'CHF', 'No'),
(39, 'Switzerland', 'CH', 'en', 'CHF', 'No'),
(40, 'Russia', 'RU', 'ru', 'RUB', 'No'),
(41, 'Russia', 'RU', 'en', 'RUB', 'No'),
(42, 'South Africa', 'ZA', 'nl', 'ZAR', 'No'),
(43, 'South Africa', 'ZA', 'en', 'ZAR', 'No'),
(44, 'Canada', 'CA', 'fr', 'CAD', 'No'),
(45, 'Canada', 'CA', 'en', 'CAD', 'No'),
(46, 'Australia', 'AU', 'en', 'AUD', 'No'),
(47, 'New Zealand', 'NZ', 'en', 'NZD', 'No'),
(48, 'China', 'CN', 'zh', 'CNY', 'No'),
(49, 'China', 'CN', 'en', 'CNY', 'No'),
(50, 'Japan', 'JP', 'jp', 'JPY', 'No'),
(51, 'Japan', 'JP', 'en', 'JPY', 'No'),
(52, 'India', 'IN', 'hi', 'INR', 'No'),
(53, 'Saudi Arabia', 'SA', 'ar', 'SAR', 'No'),
(54, 'Saudi Arabia', 'SA', 'en', 'SAR', 'No'),
(55, 'Qatar', 'QA', 'ar', 'QAR', 'No'),
(56, 'Qatar', 'QA', 'en', 'QAR', 'No'),
(57, 'Bahrain', 'BH', 'ar', 'BHD', 'No'),
(58, 'Bahrain', 'BH', 'en', 'BHD', 'No'),
(59, 'United Arab Emirates', 'AE', 'ar', 'AED', 'No'),
(60, 'United Arab Emirates', 'AE', 'en', 'AED', 'No'),
(61, 'Egypt', 'EG', 'ar', 'EGP', 'No'),
(62, 'Egypt', 'EG', 'en', 'EGP', 'No'),
(63, 'Kuwait', 'KW', 'ar', 'KWD', 'No'),
(64, 'Kuwait', 'KW', 'en', 'KWD', 'No');";


        /*--------------System Default----------------*/

        $sql[] = "INSERT INTO `" . DB_PREFIX . "cedwish_system_default` (`id`, `name`, `field_name`) VALUES
(1, 'Model', 'model'),
(2, 'Name', 'name'),
(3, 'Description', 'description'),
(4, 'Short Description', 'short_description'),
(5, 'Manufacturer', 'manufacturer'),
(6, 'Tax Rule', 'tax_rule'),
(7, 'Price (Tax Excl.)', 'price'),
(8, 'Price (Tax Incl.)', 'price_with_tax'),
(9, 'UPC', 'upc'),
(10, 'EAN', 'ean'),
(11, 'Quantity', 'quantity');";


        /*--------Execute All Query------*/

        foreach ($sql as $query) {
            if($this->db->query($query) == false) {
                return false;
            }
        }


    }

    public function uninstall() {

        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cedwish_products_cron`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cedwish_country_currency`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cedwish_order`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cedwish_order_error`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cedwish_system_default`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cedwish_mapping_details`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cedwish_product_variations`");
        $this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "cedwish_product_attribute_combination`");
    }

}