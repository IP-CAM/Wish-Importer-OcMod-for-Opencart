<?php

class ControllerCedWishOrderError extends Controller
{
	public function index()
	{
		$this->load->language('ced_wish/order_error');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('ced_wish/order_error');
		$this->getList();
	}

	public function delete() {

		$this->load->language('ced_wish/order_error');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_wish/order_error');

		if (isset($this->request->post['selected']) && $this->validate()) 
		{
			foreach ($this->request->post['selected'] as $order_id) 
			{
				$this->model_ced_wish_order_error->deleteErrorOrder($order_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('ced_wish/order_error', 'token=' . $this->session->data['token'] . $url, true));
		}

		$this->getList();
	}

	protected function getList()
	{ 
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'wish_order_id';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'DESC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_ced_wish'),
			'href' => $this->url->link('ced_wish/map_category', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('ced_wish/order_error', 'token=' . $this->session->data['token'] . $url, true)
		);

		$data['delete'] = $this->url->link('ced_wish/order_error/delete', 'token=' . $this->session->data['token'], true);
		
		$order_total = $this->model_ced_wish_order_error->getErrorOrdersTotals();

		$results = $this->model_ced_wish_order_error->getErrorOrders();
	
        $data['order_error'] = array();
		foreach ($results as $result) {
			$data['order_error'][] = array(
				'sku'        => $result['sku'],
				'wish_order_id' => $result['wish_order_id'],
				'reason'              => $result['reason'],
				'cancel'              => $this->url->link('ced_wish/order_error/cancelOrder', 'token=' . $this->session->data['token'] . '&wish_order_id=' . $result['wish_order_id'] . $url, true)
			);
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_error_list'] = $this->language->get('text_error_list');
		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_confirm'] = $this->language->get('text_confirm');

		$data['column_sku'] = $this->language->get('column_sku');
		$data['column_wish_order_id'] = $this->language->get('column_wish_order_id');
		$data['column_reason'] = $this->language->get('column_reason');
		$data['column_action'] = $this->language->get('column_action');
		
		$data['button_delete'] = $this->language->get('button_delete');
		$data['button_cancel'] = $this->language->get('button_cancel');

		$data['token'] = $this->session->data['token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}
		
		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_merchant_sku'] = $this->url->link('ced_wish/order_error', 'token=' . $this->session->data['token'] . '&sort=sku' . $url, true);
		$data['sort_wish_order_id'] = $this->url->link('ced_wish/order_error', 'token=' . $this->session->data['token'] . '&sort=wish_order_id' . $url, true);
		$data['sort_reason'] = $this->url->link('ced_wish/order_error', 'token=' . $this->session->data['token'] . '&sort=reason' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $order_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('ced_wish/order_error', 'token=' . $this->session->data['token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($order_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($order_total - $this->config->get('config_limit_admin'))) ? $order_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $order_total, ceil($order_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('ced_wish/order_error_list.tpl', $data));

	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'ced_wish/order_error')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		return !$this->error;
	}

}

?>