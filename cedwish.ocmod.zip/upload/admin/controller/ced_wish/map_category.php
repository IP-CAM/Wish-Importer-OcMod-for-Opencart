<?php

class ControllerCedWishMapCategory extends Controller
{
	private $error = array();
	
	public function index() {
	
		$this->load->language('ced_wish/map_category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_wish/map_category');

		$this->getList();
	}

	public function add() {

		$this->load->language('ced_wish/map_category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_wish/map_category');
       
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
	
			$this->model_ced_wish_map_category->addCategoryMapping($this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('ced_wish/map_category', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getForm();
	}

	public function edit() {

		$this->load->language('ced_wish/map_category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_wish/map_category');
  
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) 
		{
			$this->model_ced_wish_map_category->editCategoryMapping($this->request->get['mapped_id'], $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('ced_wish/map_category', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getForm();
	}

	public function delete() {

		$this->load->language('ced_wish/map_category');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('ced_wish/map_category');

		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $category_id) {
				$this->model_ced_wish_map_category->deleteCategoryMapping($category_id);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('ced_wish/map_category', 'token=' . $this->session->data['token'] . $url, 'SSL'));
		}

		$this->getList();
	}

	protected function getList() {

		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'name';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_ced_wish'),
			'href' => $this->url->link('ced_wish/map_category', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('ced_wish/map_category', 'token=' . $this->session->data['token'] . $url, 'SSL')
		);
		
		$data['add'] = $this->url->link('ced_wish/map_category/add', 'token=' . $this->session->data['token'] . $url, 'SSL');
		$data['delete'] = $this->url->link('ced_wish/map_category/delete', 'token=' . $this->session->data['token'] . $url, 'SSL');

		$data['categories'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$this->load->model('ced_wish/map_category');

		$category_total = $this->model_ced_wish_map_category->getTotalMappingDetails();

		$results = $this->model_ced_wish_map_category->getMappingDetails($filter_data);

		foreach ($results as $result) {

           $cat = json_decode($result['category'], true);
	       $store_category ='';
	       $store_result = '';

	       if($cat){
	           foreach($cat as $store_id){
		           	if($store_id != ''){
		           	  $store_category = $this->model_ced_wish_map_category->getStoreCategory($store_id);
		           	  $store_result .= $store_category . ',';

		            }
	            }  
            }
            
			$data['categories'][] = array(
				'mapped_id'       => $result['mapped_id'],
				'CategoryName'    => $result['CategoryName'],
				'category'        => rtrim($store_result, ','),
				'status'          => $result['status'] ? $this->language->get('text_enabled') : $this->language->get('text_disabled'),
				'edit'            => $this->url->link('ced_wish/map_category/edit', 'token=' . $this->session->data['token'] . '&mapped_id=' . $result['mapped_id'] . $url, 'SSL'),
				'delete'      => $this->url->link('ced_wish/map_category/delete', 'token=' . $this->session->data['token'] . '&mapped_id=' . $result['mapped_id'] . $url, 'SSL')
			); 
		} 

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_list'] = $this->language->get('text_list');
		$data['text_no_results'] = $this->language->get('text_no_results');
		$data['text_confirm'] = $this->language->get('text_confirm');

		$data['column_name'] = $this->language->get('column_name');
		$data['column_category'] = $this->language->get('column_category');
		$data['column_status'] = $this->language->get('column_status');
		$data['column_action'] = $this->language->get('column_action');

		$data['button_add'] = $this->language->get('button_add');
		$data['button_edit'] = $this->language->get('button_edit');
		$data['button_delete'] = $this->language->get('button_delete');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_name'] = $this->url->link('ced_wish/map_category', 'token=' . $this->session->data['token'] . '&sort=name' . $url, 'SSL');
		$data['sort_category'] = $this->url->link('ced_wish/map_category', 'token=' . $this->session->data['token'] . '&sort=category' . $url, 'SSL');
		$data['sort_status'] = $this->url->link('ced_wish/map_category', 'token=' . $this->session->data['token'] . '&sort=status' . $url, 'SSL');

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $category_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('ced_wish/map_category', 'token=' . $this->session->data['token'] . $url . '&page={page}', 'SSL');

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf($this->language->get('text_pagination'), ($category_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($category_total - $this->config->get('config_limit_admin'))) ? $category_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $category_total, ceil($category_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('ced_wish/map_category_list.tpl', $data));
	}

	protected function getForm() {

		$data['heading_title'] = $this->language->get('heading_title');
		
		$data['text_form'] = !isset($this->request->get['mapped_id']) ? $this->language->get('text_add') : $this->language->get('text_edit');
		$data['text_none'] = $this->language->get('text_none');
		$data['text_default'] = $this->language->get('text_default');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');

		$data['text_option'] = $this->language->get('text_option');
		$data['text_attribute_variants'] = $this->language->get('text_attribute_variants');
		$data['text_system_default'] = $this->language->get('text_system_default');

		$data['entry_category_name'] = $this->language->get('entry_category_name');
		$data['entry_stock_category'] = $this->language->get('entry_stock_category');
		$data['entry_manufacturer'] = $this->language->get('entry_manufacturer');
		$data['entry_store'] = $this->language->get('entry_store');
		$data['entry_language'] = $this->language->get('entry_language');
		$data['entry_status'] = $this->language->get('entry_status');

		$data['help_filter'] = $this->language->get('help_filter');
		$data['help_keyword'] = $this->language->get('help_keyword');
		$data['help_top'] = $this->language->get('help_top');
		$data['help_column'] = $this->language->get('help_column');
		$data['help_category'] = $this->language->get('help_category');
		$data['help_manufacturer'] = $this->language->get('help_manufacturer');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		$data['tab_map_category'] = $this->language->get('tab_map_category');
		$data['tab_attribute'] = $this->language->get('tab_attribute');
		$data['tab_default'] = $this->language->get('tab_default');
		$data['tab_variant_attribute'] = $this->language->get('tab_variant_attribute');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		} 

		if (isset($this->error['code'])) {
			$data['error_code'] = $this->error['code'];
		} else {
			$data['error_code'] = '';
		} 
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('ced_wish/category', 'token=' . $this->session->data['token'] . $url, 'SSL')
		);
		
		if (!isset($this->request->get['mapped_id'])) {
			$data['action'] = $this->url->link('ced_wish/map_category/add', 'token=' . $this->session->data['token'] . $url, 'SSL');
		} else {
			$data['action'] = $this->url->link('ced_wish/map_category/edit', 'token=' . $this->session->data['token'] . '&mapped_id=' . $this->request->get['mapped_id'] . $url, 'SSL');
		}

		$data['cancel'] = $this->url->link('ced_wish/map_category', 'token=' . $this->session->data['token'] . $url, 'SSL');

		if (isset($this->request->get['mapped_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$mapping_details = $this->model_ced_wish_map_category->getMappingDetailsByID($this->request->get['mapped_id']);

			$catagories      = json_decode($mapping_details['category'], true);
			$manufacturers   = json_decode($mapping_details['manufacturer'], true);
			$OpencartStore   = json_decode($mapping_details['product_store'], true);
			$attribute_array = json_decode($mapping_details['attribute'], true);
	        $variant_array   = json_decode($mapping_details['variant_attribute'], true);
		    $default_array   = json_decode($mapping_details['default_attribute'], true);
		    if(!is_array($catagories) || empty($catagories))
		    {
		    	$catagories = array();
		    }
		    if(!is_array($manufacturers) || empty($manufacturers))
		    {
		    	$manufacturers = array();
		    }
		    if(!is_array($OpencartStore) || empty($OpencartStore))
		    {
		    	$OpencartStore = array();
		    }
		    if(!is_array($attribute_array) || empty($attribute_array))
		    {
		    	$attribute_array = array();
		    }
		    if(!is_array($variant_array) || empty($variant_array))
		    {
		    	$variant_array = array();
		    }
		    if(!is_array($default_array) || empty($default_array))
		    {
		    	$default_array = array();
		    }

		}

		$data['token'] = $this->session->data['token'];

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();

		$this->load->model('ced_wish/map_category');

		$data['countries'] = $this->model_ced_wish_map_category->getCountry();

		$data['currencies'] = $this->model_ced_wish_map_category->getCurrency();

		$data['fruugoLanguage'] = $this->model_ced_wish_map_category->getFruugoLanguage();

		$data['systemDefault'] = $this->model_ced_wish_map_category->getSystemDefault();
         
		// Fruugo categories
		if (isset($this->request->post['CategoryName'])) {
			$data['CategoryName'] = $this->request->post['CategoryName'];
		} elseif (!empty($mapping_details)) {
			$data['CategoryName'] = $mapping_details['CategoryName'];
		} else {
			$data['CategoryName'] = '';
		}

		//Profile Status
		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($mapping_details)) {
			$data['status'] = $mapping_details['status'];
		} else {
			$data['status'] = '';
		}

	    // Stock Categories
		$this->load->model('catalog/category');

		if (isset($this->request->post['product_category'])) {
			$categories = $this->request->post['product_category'];
		} elseif (!empty($catagories)) {
			$categories = $catagories;
		} else {
			$categories = array();
		}

		$data['product_categories'] = array();

		foreach ($categories as $category_id) {
			$category_info = $this->model_catalog_category->getCategory($category_id);

			if ($category_info) {
				$data['product_categories'][] = array(
					'category_id' => $category_info['category_id'],
					'name' => ($category_info['path']) ? $category_info['path'] . ' &gt; ' . $category_info['name'] : $category_info['name']
				);
			}
		}

		// Manufacturer
		$this->load->model('catalog/manufacturer');

		if (isset($this->request->post['manufacturer_id'])) {
			$manufacturers = $this->request->post['manufacturer_id'];
		} elseif (!empty($manufacturers)) {
			$manufacturers = $manufacturers;
		} else {
			$manufacturers = array();
		}

		$data['manufacturers'] = array();

		foreach ($manufacturers as $manufacturer) {
			$manufacturer_info = $this->model_catalog_manufacturer->getManufacturer($manufacturer);

			if ($manufacturer_info) {
				$data['manufacturers'][] = array(
					'manufacturer_id' => $manufacturer_info['manufacturer_id'],
					'name' => $manufacturer_info['name']
				);
			}
		}

		$this->load->model('setting/store');

		$data['stores'] = $this->model_setting_store->getStores();

		if (isset($this->request->post['product_store'])) {
			$data['product_store'] = $this->request->post['product_store'];
		} elseif (isset($this->request->get['product_id'])) {
			$data['product_store'] = $this->model_catalog_product->getProductStores($this->request->get['product_id']);
		} else {
			$data['product_store'] = array(0);
		}

		// Store Language
		$this->load->model('localisation/language');
		$mapped_fruugo_language = $this->config->get('ced_wish_language');
		
		if(isset($this->request->post['storeLanguage'])) {
			$data['storeLanguage'] = $this->request->post['storeLanguage'];
		} elseif(isset($mapped_fruugo_language) && !empty($mapped_fruugo_language)){
           $data['storeLanguage'] = $mapped_fruugo_language;
		} elseif (!empty($mapping_details)) {
			$data['storeLanguage'] = $mapping_details['storeLanguage'];
		} else {
			$data['storeLanguage'] = '';
		}

		// Attributes
		$this->load->model('catalog/attribute');

		$data['stock_attributes'] = $this->model_catalog_attribute->getAttributes();

		// Options
		$this->load->model('catalog/option');

		$options = $this->model_catalog_option->getOptions();

		foreach($options as $option){

		    $type = '';

			if ($option['type'] == 'select' || $option['type'] == 'radio' || $option['type'] == 'checkbox' || $option['type'] == 'image') {
				$type = $this->language->get('text_choose');
				$json[] = array(
					'option_id'    => $option['option_id'],
					'name'         => strip_tags(html_entity_decode($option['name'], ENT_QUOTES, 'UTF-8')),
					'category'     => $type,
					'type'         => $option['type'],
		        );
			}			
		}
 
		$data['options'] = $json;

		// Validation Array
		$data['validation_array'] = $this->validationArray();
		$validation_array = $data['validation_array'];
		$validation_keys = array_keys($validation_array);
        
        // Attributes
		foreach ($validation_keys as $key => $value) {

			if(in_array($value ,array('product_id', 'msrp', 'shipping_time', 'stock_status','brand','landing_page_url', 'main_image', 'extra_images', 'size', 'color', 'upc', 'max_quantity', 'length', 'width', 'height', 'weight', 'declared_value', 'hscode', 'origin_country', 'has_powder', 'has_liquid', 'has_battery', 'has_metal','category'))){
				continue;
			} else {

				if (isset($this->request->post['attribute'][$value])) {
				$data['mapped_attribute'][$value] = $this->request->post['attribute'][$value];
				} elseif (!empty($attribute_array) && isset($attribute_array[$value]) ) {
					$data['mapped_attribute'][$value] = $attribute_array[$value];
				} else {
					$data['mapped_attribute'][$value] = '';
				}
		    }

		}

		// Default Attributes
		foreach ($validation_keys as $key => $value) {

		    if(!in_array($value ,array('sku', 'parent_sku', 'tags', 'shipping', 'inventory', 'msrp', 'shipping_time', 'brand','landing_page_url', 'upc', 'max_quantity', 'length', 'width', 'height', 'weight', 'declared_value', 'hscode', 'origin_country', 'has_powder', 'has_liquid', 'has_battery', 'has_metal'))){
		    	continue;
		    } else {

		    	if (isset($this->request->post['default_attribute'][$value])) {
			    $data['default_attribute'][$value] = $this->request->post['default_attribute'][$value];
			    } elseif (!empty($default_array) && isset($default_array[$value]) ) {
				$data['default_attribute'][$value] = $default_array[$value];
			    } else {
				$data['default_attribute'][$value] = '';
			    }

		    }

		}

		// Variant Attributes
		$data['variant_attributes'] = $this->variantAttributes();
		$variant_attributes = $data['variant_attributes'];
		$variant_keys = array_keys($variant_attributes);

		foreach ($variant_keys as $key => $value) {

			if (isset($this->request->post['variant_attribute'][$value])) {
			$data['variant_attribute'][$value] = $this->request->post['variant_attribute'][$value];
			}
			   elseif (!empty($variant_array) && isset($variant_array[$value]) ) {
				$data['variant_attribute'][$value] = $variant_array[$value];
				// echo $mapping_details['variant_attribute'][$key]; die();
			} else {
				$data['variant_attribute'][$value] = '';
			}

		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
    //echo '<pre>'; print_r($data); die();
		$this->response->setOutput($this->load->view('ced_wish/map_category_form.tpl', $data));
	}

	public function validationArray(){

    return array(
            'product_id' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50,
                'description' => 'Your own product identifier code that you recognise when it is provided on order information.The same ProductId should be used to group together Skus where they are available with multiple options (Colours, Sizes etc.).'
            ),
            'name' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 150,
                'description' => '  Name of the product as shown to users on Wish.'
            ),
            'description' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 5000,
                'description' => 'Description of the product. Should not contain HTML. If you want a new line use "\n".'
            ),
            'declared_name' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 150,
                'description' => 'Product name for logistics declaration.'
            ),
            'declared_local_name' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 150,
                'description' => 'Product name written in local language for logistics declaration.'
            ),
            'pieces' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 5,
                'description' => 'The amount of pieces associated with this item.'
            ),
            'tags' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 100,
                'description' => 'Comma separated list of strings that describe the product. Only 10 are allowed. Any tags past 10 will be ignored.'
            ),
            'sku' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50,
                'description' => 'The unique identifier that your system uses to recognize this product.'
            ),
            'size' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => ' The size of the product. Example: Large, Medium, Small, 5, 6, 7.5.'
            ),
            'color' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'The color of the product. Example: red, blue, green.'
            ),
            'inventory' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 7,
                'description' => 'The physical quantities you have for this product, max 500,000'
            ),
            'price' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 7,
                'description' => "The price of the variation when the user purchases one, max 100,000."
            ),
            'shipping' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 10,
                'description' => "The shipping of the product when the user purchases one, max 1000."
            ),
            'msrp' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 7,
                'description' => "Manufacturer's Suggested Retail Price. This field is recommended as it will show as a strikethrough price on Wish and appears above the selling price for the product."
            ),
            'shipping_time' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 10,
                'description' => "The amount of time it takes for the shipment to reach the buyer. Please also factor in the time it will take to fulfill and ship the item. Provide a time range in number of days. Lower bound cannot be less than 2 days. Upper bound must be at least 5 days after the lower bound. Example: 15-20."
            ),
            'main_image' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 2150,
                'description' => 'URL of a photo of your product. Link directly to the image, not the page where it is located. We accept JPEG, PNG or GIF format. Images should be at least 100 x 100 pixels in size.'
            ),
            'parent_sku' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 50,
                'description' => 'When defining a variant of a product we must know which product to attach the variation to. parent_sku is the unique id of the product that you can use later when using the add product variation API..'
            ),
            'brand' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 100,
                'description' => 'Brand or manufacturer of your product.'
            ),
            'landing_page_url' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 50,
                'description' => 'URL on your website containing the product details.'
            ),
            'upc' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 12,
                'description' => '12-digit Universal Product Codes (UPC)-contains no letters or other characters.'
            ),
            'extra_images' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 2150,
                'description' => "URL of extra photos of your product. Link directly to the image, not the page where it is located. Same rules apply as Imageurl1. You can specify one or more additional images separated by the character '|'. The total number of extra images plus the number of variation images must not exceed 20."
            ),
            'max_quantity' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 5,
                'description' => "The maximum quantity of products per order."
            ),
            'length' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 10,
                'description' => "The length of your product that will be packaged to ship to customer (Units in cm)."
            ),
            'width' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 10,
                'description' => "The width of your product that will be packaged to ship to customer (Units in cm)."
            ),
            'height' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 10,
                'description' => "The height of your product that will be packaged to ship to customer (Units in cm)."
            ),
            'weight' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 10,
                'description' => "The weight of your product that will be packaged to ship to customer (Units in cm)."
            ),
            'declared_value' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 7,
                'description' => "The price of your product that will be declared to custom."
            ),
            'hscode' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 30,
                'description' => "Harmonization System Code used for custom declaration."
            ),
            'origin_country' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 150,
                'case' => 'upper',
                'values' => $this->model_ced_wish_map_category->getCountry(),
                'description' => 'Country where product is manufactured. Country code should follow ISO 3166 Alpha-2 code. Example:CN, US.'
            ),
            'has_powder' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 10,
                'description' => 'Whether product contains powder. Example: true, false.'
            ),
            'has_liquid' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 10,
                'description' => 'Whether product contains liquid. Example: true, false.'
            ),
            'has_battery' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 10,
                'description' => 'Whether product contains battery. Example: true, false.'
            ),
            'has_metal' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 10,
                'description' => 'Whether product contains metal. Example: true, false.'
            )
            //  'category' => array(
            //     'type' => 'string',
            //     'is_required' => false ,
            //     'length' => 250,
            //     'description' => 'The category name where the product is located on your own website or the category you wish the product to be classified in on Wish.'
            // ),
            // 'stock_status' => array(
            //     'type' => 'select',
            //     'is_required' => false ,
            //     'length' => 12,
            //     'values' => array(
            //         'INSTOCK' => 'INSTOCK',
            //         'OUTOFSTOCK' => 'OUTOFSTOCK',
            //         'NOTAVAILABLE' => 'NOTAVAILABLE',
            //     ),
            //     'description' => 'The stock status of a product which indicates whether it’s available for purchase. The value of the field must be either:</br>
            //                     INSTOCK – If you have the product currently in stock.</br>
            //                     OUTOFSTOCK – The product is currently out of stock but may return.</br>
            //                     NOTAVAILABLE – The product is permanently out of stock and needs to be removed.'
            // )
        );
  }

	public function variantAttributes()
    {
        return array(
            'size' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'The specific size option of the SKU, which where a product is available in several size choices will present the size option to the retailer. Note: The field becomes mandatory if you have products which are available in multiple sizes.
								We recommend including the size for all products, however the field should not include generic terms such as one size or o/s.'
            ),
            'color' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'The specific colour option of the SKU, which where a product is available in several colours choices will present the colour option to the retailer. Note: The field becomes mandatory if you have products which are available in multiple colours.
								We recommend including the colour for all products, however the field should not include generic terms such as multi-coloured, mixed or one colour.'
            )
        );
    }

    	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'ced_wish/map_category')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (utf8_strlen($this->request->post['CategoryName']) < 3) {
			$this->error['name'] = $this->language->get('error_name');
		}

		if ($this->request->post['category']) {
			if(utf8_strlen($this->request->post['product_category']) < 3){
				$this->error['code'] = $this->language->get('error_code');
			}
		}
		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'ced_wish/map_category')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}

     public function autocomplete() {
		$json = array();

		if (isset($this->request->get['FruugoCategory'])) {
			$this->load->model('ced_wish/category');

			$filter_data = array(
				'filter_name' => $this->request->get['FruugoCategory'],
				'start'       => 0,
				'limit'       => 5
			);

			$results = $this->model_ced_wish_category->getCedwishCategory($filter_data);

			foreach ($results as $result) {
				$json[] = array(
					'category_id'    => $result['category_id'],
					'name'            => strip_tags(html_entity_decode($result['name'], ENT_QUOTES, 'UTF-8')),
					// 'map_categories' => $result['map_categories']
				);
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
    
}

?>