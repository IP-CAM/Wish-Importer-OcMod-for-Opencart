<?php

class ControllerModuleCedWish extends Controller
{
    private $error = array();

    public function index(){

        $this->load->language('module/ced_wish');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if(($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()){
            $this->model_setting_setting->editSetting('ced_wish', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');

            $this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_edit']      = $this->language->get('text_edit');
        $data['text_enabled']   = $this->language->get('text_enabled');
        $data['text_disabled']  = $this->language->get('text_disabled');

        // Tabs
        $data['tab_general']      = $this->language->get('tab_general');
        $data['tab_wish_product'] = $this->language->get('tab_wish_product');
        $data['tab_wish_order']  = $this->language->get('tab_wish_order');
        $data['tab_wish_cron']   = $this->language->get('tab_wish_cron');
        // $data['tab_wish_chunk']  = $this->language->get('tab_wish_chunk');

        // General Tab
        $general_tabs = array('status', 'api_mode', 'api_mode_url', 'redirect_uri', 'generate_code', 'access_token', 'refresh_token', 'enable_logging');

        foreach ($general_tabs as $general_tab) 
         {
           $data['entry_' . $general_tab] = $this->language->get('entry_' . $general_tab);  
         }
        
         $data['button_generate']       = $this->language->get('button_generate');
         $data['button_validate']       = $this->language->get('button_validate');
         $data['button_refresh']        = $this->language->get('button_refresh');

        // https://demo.cedcommerce.com/integration/opencart2.0/index.php?route=ced_wish/success

        // Wish Product Settings Tab
        $product_tabs = array('product_price', 'product_price_fixed', 'product_price_percentage', 'default_tags', 'default_shipping', 'auto_update_product');
         
        foreach ($product_tabs as $product_tab) 
        {
          $data['entry_' . $product_tab] = $this->language->get('entry_' . $product_tab);
        }

        // Wish Order Settings Tab
        $order_tabs = array('order_noti_email', 'default_customer_email', 'cancel_order', 'accept_order');

        foreach ($order_tabs as $order_tab) 
        {
          $data['entry_' . $order_tab] = $this->language->get('entry_' . $order_tab);
        }

        // Wish Cron Settings Tab
        $cron_tabs = array('order_cron', 'order_cron_time', 'inventory_cron', 'inventory_cron_time');

        foreach ($cron_tabs as $cron_tab) 
        {
          $data['entry_' . $cron_tab] = $this->language->get('entry_' . $cron_tab);
          $data['ced_wish_' . $cron_tab] = $this->language->get('ced_wish_' . $cron_tab);
        }

        // Wish Chunk Settings Tab
        // $chunk_tabs = array('validate_chunk_size', 'upload_chunk', 'eds_chunk');

        // foreach ($chunk_tabs as $chunk_tab) 
        // {
        //   $data['entry_' . $chunk_tab] = $this->language->get('entry_' . $chunk_tab);
        // }

        $data['button_save']    = $this->language->get('button_save');
        $data['button_cancel']  = $this->language->get('button_cancel');

        if(isset($this->error['warning'])){
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if(isset($this->error['code'])){
            $data['error_code'] = $this->error['code'];
        } else {
            $data['error_code'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_module'),
            'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('module/ced_wish', 'token=' . $this->session->data['token'], 'SSL')
        );

        $data['action'] = $this->url->link('module/ced_wish', 'token=' . $this->session->data['token'], 'SSL');

        $data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

        $public_app_url = 'https://apps.cedcommerce.com/marketplace-integration/wish/auth/authorise';
        $redirect_uri = $this->url->link('module/ced_wish', 'token=' . $this->session->data['token'], 'SSL');

        if ($this->config->get('ced_wish_api_mode') == 'sandbox'){
            $mode = '2';
            $data['generate'] = $public_app_url . '?mode=' . $mode . '&redirect_uri=' . urlencode($redirect_uri);
        } else {
            $mode = '1';
            $data['generate'] = $public_app_url . '?mode=' . $mode . '&redirect_uri=' . urlencode($redirect_uri);
        }

        $this->load->model('ced_wish/success');
        $this->load->library('cedwish');
        $cedwish = Cedwish::getInstance($this->registry);

        if(!empty($this->request->get['code'])){
            $data['code'] = $this->request->get['code'];
            $this->model_ced_wish_success->editSetting('ced_wish', 'ced_wish_generate_code' , $this->request->get['code']);
            $accessToken = $cedwish->getAccessToken($this->request->get['code'], $redirect_uri);
            $data['success'] = 'Your Code is: <strong>' . $data['code'] . '</strong> <br/>  Please refresh your page and save the settings.';
        }

        // if ($this->config->get('ced_wish_api_mode') == 'sandbox'){
        //     $this->apiHost = 'https://sandbox.merchant.wish.com/oauth/authorize?client_id=';
        //     $clientId = $this->config->get('ced_wish_sandbox_client_id');
        //     $data['generate'] = $this->apiHost . $clientId;
        // } else {
        //     $this->apiHost = 'https://merchant.wish.com/oauth/authorize?client_id=';
        //     $clientId = $this->config->get('ced_wish_production_client_id');
        //     $data['generate'] = $this->apiHost . $clientId;
        // }

         $data['token'] = $this->session->data['token'];

         $this->load->model('localisation/language');

         $data['languages'] = $this->model_localisation_language->getLanguages();

        // General Tab
        foreach ($general_tabs as $general_tab) {
            if (isset($this->request->post['ced_wish_' . $general_tab])) {
                $data['ced_wish_' . $general_tab] = $this->request->post['ced_wish_' . $general_tab];
            } else {
                $data['ced_wish_' . $general_tab] = $this->config->get('ced_wish_' . $general_tab);
            }
        }
        $data['ced_wish_redirect_uri'] = $redirect_uri;
        
        // Wish Product Settings
        foreach ($product_tabs as $product_tab) {
            if (isset($this->request->post['ced_wish_' . $product_tab])) {
                $data['ced_wish_' . $product_tab] = $this->request->post['ced_wish_' . $product_tab];
            } else {
                $data['ced_wish_' . $product_tab] = $this->config->get('ced_wish_' . $product_tab);
            }
        }

        // Wish Order Settings
        foreach ($order_tabs as $order_tab) {
            if (isset($this->request->post['ced_wish_' . $order_tab])) {
                $data['ced_wish_' . $order_tab] = $this->request->post['ced_wish_' . $order_tab];
            } else {
                $data['ced_wish_' . $order_tab] = $this->config->get('ced_wish_' . $order_tab);
            }
        }

        // Wish Cron Settings
        // foreach ($cron_tabs as $cron_tab) {
        //     if (isset($this->request->post['ced_wish_' . $cron_tab])) {
        //         $data['ced_wish_' . $cron_tab] = $this->request->post['ced_wish_' . $cron_tab];
        //     } else {
        //         $data['ced_wish_' . $cron_tab] = $this->config->get('ced_wish_' . $cron_tab);
        //     }
        // }

        // Wish Chunk Settings
        // foreach ($chunk_tabs as $chunk_tab) {
        //     if (isset($this->request->post['ced_wish_' . $chunk_tab])) {
        //         $data['ced_wish_' . $chunk_tab] = $this->request->post['ced_wish_' . $chunk_tab];
        //     } else {
        //         $data['ced_wish_' . $chunk_tab] = $this->config->get('ced_wish_' . $chunk_tab);
        //     }
        // }

        $data['header']  = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('module/ced_wish.tpl', $data));

    }

    protected function validate(){
        if(!$this->user->hasPermission('modify', 'module/ced_wish')){
            $this->error['warning'] = $this->language->get('error_permission');
        }

        // if(!$this->request->post['ced_wish_sandbox_client_id'] && !$this->request->post['ced_wish_sandbox_client_secret']){
        //     $this->error['code'] = $this->language->get('error_code');
        // } elseif(!$this->request->post['ced_wish_sandbox_client_id']){
        //     $this->error['code'] = $this->language->get('error_code');
        // } elseif(!$this->request->post['ced_wish_sandbox_client_secret']){
        //     $this->error['code'] = $this->language->get('error_code');
        // }

        return !$this->error;
    }

    public function refreshToken()
    {
        $this->load->library('cedwish');
        $cedwish = Cedwish::getInstance($this->registry);
        $auth = $cedwish->refreshToken();
        $response = array();
        if(isset($auth['success']) && $auth['success'] == true){
            $response['success'] = true;
            $response['message'] = 'Token Refreshed Successfully';
        } else {
            $response['success'] = false;
            $response['message'] = ($auth['message'])?$auth['message']:'Credentials not available.';
        }
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($response));
    }

    public function validateToken()
    {
        $this->load->library('cedwish');
        $cedwish = Cedwish::getInstance($this->registry);
        $accessToken = $this->config->get('ced_wish_access_token');
        $result = $cedwish->validateToken($accessToken);
        $response = array();
        if(isset($result) && $result['success'] == true){
            $response['success'] = true;
            $response['message'] = 'Token Validated Successfully';
        } else {
            $response['success'] = false;
            $response['message'] = ($result['message'])?$result['message']:'Credentials not available.';
        }
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($response));
    }

    public function install(){

        $this->load->model('module/cedwish_category');

        $this->model_module_cedwish_category->install();
        
        $this->load->model('user/user_group');

        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'module/ced_wish');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'module/ced_wish');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_wish/map_category');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_wish/map_category');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_wish/order');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_wish/order');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_wish/order_error');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_wish/order_error');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'ced_wish/product');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'ced_wish/product');

        $shop_email =  $this->config->get('config_email');
        $shop_url = HTTPS_CATALOG;

        $require_data =  array('domain'=>$shop_url, 'email'=>$shop_email, 'framework'=>'Opencart');
        //$cedcommerce_url = 'http://admin.apps.cedcommerce.com/magento-fruugo-info/create'.$require_data;
        $cedcommerce_url = 'http://admin.apps.cedcommerce.com/magento-fruugo-info/create&domain=<?php echo $shop_url; ?>&email=<?php echo $shop_email; ?>&framework=Opencart';

        $ch = curl_init($cedcommerce_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);

        // Check if any error occurred
        if (curl_errno($ch)) {
            $this->load->library('cedwish');
            $cedwish = Cedwish::getInstance($this->registry);
            // $cedwish = new CedfruugoHelper;
            $cedwish->log(
                METHOD,
                'Warning',
                'Install Message curl error',
                curl_errno($ch)
            );
        }

        // Close handle
        curl_close($ch);

        $this->load->model('extension/event');

        $this->model_extension_event->addEvent('ced_wish', 'post.admin.product.add', 'ced_wish/product/addNewProductsToVariants');
    }

    public function uninstall(){

        // $this->load->model('module/cedwish_category');

        $this->load->model('user/user_group');

        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'module/ced_wish');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'module/ced_wish');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_wish/map_category');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_wish/map_category');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_wish/order');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_wish/order');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_wish/order_error');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_wish/order_error');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'access', 'ced_wish/product');
        $this->model_user_user_group->removePermission($this->user->getGroupId(), 'modify', 'ced_wish/product');

        $this->load->model('extension/event');

        $this->model_extension_event->deleteEvent('ced_wish');
    }
}

?>