<?php

class Cedwish {
    private $logger;
    // private $api_url = 'https://merchant.wish.com/api/v2/';
    // private $api_version = 'v2';
    private static $instance;

    /**
     * @param  object  $registry  Registry Object
     */
    public static function getInstance($registry) {
        if (is_null(static::$instance)) {
            static::$instance = new static($registry);
        }

        return static::$instance;
    }

    /**
     * @param  object  $registry  Registry Object
     *
     *   $registry->get('log');
     *   $registry->get('db');
     *   $registry->get('config');
     */
    public function __construct($registry) {
        $this->logger   = $registry->get('log');
        $this->db       = $registry->get('db');
        $this->config   = $registry->get('config');
        $this->currency = $registry->get('currency');
        $this->tax      = new Tax($registry);
        $this->prepareConfiguration();
    }

    public function prepareConfiguration()
    {
        if($this->config->get('ced_wish_api_mode') == 'sandbox')
            $this->apiHost = 'https://sandbox.merchant.wish.com/api/v2/';
        else
            $this->apiHost = 'https://merchant.wish.com/api/v2/';

        // if(!empty($this->config->get('ced_wish_sandbox_client_id'))){
        //     $clientId = $this->config->get('ced_wish_sandbox_client_id');
        //     $clientSecret = $this->config->get('ced_wish_sandbox_client_secret');
        // } else {
        //     $clientId = $this->config->get('ced_wish_production_client_id');
        //     $clientSecret = $this->config->get('ced_wish_production_client_secret');
        // }
        $clientId = '5b3c7b2e19c76b2c8f1c4b0f';
        $clientSecret = '019f1c3a906d48ca941e2392255f5620';
        $refreshToken = $this->config->get('ced_wish_refresh_token');
        $accessToken = $this->config->get('ced_wish_access_token');
        $redirectUri = 'https://apps.cedcommerce.com/marketplace-integration/wish/auth/index';

        $this->clientId = $clientId;
        $this->clientSecret = $clientSecret;
        $this->refreshToken = $refreshToken;
        $this->accessToken = $accessToken;
        $this->redirectUri = $redirectUri;
    }

    public function isEnabled(){

        $flag=false;

        if ($this->config->get('ced_wish_status')) {

            $flag=true;

            $this->_init();
        }
        return $flag;
    }

    public function _init(){

        $this->_api_url = $this->config->get('ced_wish_redirect_uri');
        $this->log("url: ".$this->_api_url);
    }

    public function deleteProducts($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0){
            $product_ids = $this->getAllWishProducts();
        }
        if(count($product_ids)) {
            foreach ($product_ids as $key => $product_id) {
                $response = array();
                try {
                    $product_data = $this->prepareWishProduct($product_id);

                    if(isset($product_data) && !empty($product_data)) {
                        $this->db->query("DELETE FROM `".DB_PREFIX."ced_wish_product` where `product_id` = '".$product_id."'");
                        return array('success' => true, 'message' => 'Product Deleted On Wish ');
                    } else {
                        return array('success' => false, 'message' => 'Failed To Delete Product On Wish');
                    }
                } catch (Exception $e) {
                    return array('success' => false, 'message' => 'No Response From Wish');
                }
            }
        }
    }

    public function enableProducts($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0){
            $product_ids = $this->getAllWishProducts();
        }
        if(count($product_ids)) {
            foreach ($product_ids as $key => $product_id) {
                try {
                    // $response = $this->updateStock($product_id, 'enable');
                    $path = 'product/enable';
                    $query = $this->db->query("SELECT wish_product_id FROM `". DB_PREFIX ."cedwish_product_response` WHERE product_id = '". $product_id ."' ");
                    $result = $query->row;

                    if(isset($result) && !empty($result['wish_product_id']))
                    {
                        $params = array(
                            'id' => $result['wish_product_id'],
                            'access_token' => $this->accessToken
                        );
                        $tokenResponse = $this->postRequest($path, $params);
                        $request = $tokenResponse['response'];

                        if(isset($request['code']) && $request['code'] == 0) {
                            $this->db->query("UPDATE `". DB_PREFIX ."cedwish_product_variations` SET wish_status = 'Enabled', wish_product_id = '". $result['wish_product_id'] ."' WHERE product_id = '". $product_id ."' ");

                            $variantEnable = $this->enableProductVariants($product_id);

                            return array('success' => true, 'message' => 'Product Enabled On Wish ');
                        } else {
                            return array('success' => false, 'message' => 'Failed To Enable Product On Wish');
                        }
                    } else {
                        return array('success' => false, 'message' => 'Error While Enabling Product');
                    }
                } catch (Exception $e) {
                    return array('success' => false, 'message' => 'No Response From Wish');
                }
            }
        }
    }
    public function disableProducts($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0){
            $product_ids = $this->getAllWishProducts();
        }
        if(count($product_ids)) {
            foreach ($product_ids as $key => $product_id) {
                $product_id = (int)$product_id;
                try {
                    // $response = $this->updateStock($product_id, 'disable');
                    $path = 'product/disable';
                    $query = $this->db->query("SELECT wish_product_id FROM `". DB_PREFIX ."cedwish_product_response` WHERE product_id = '". $product_id ."' ");
                    $result = $query->row;
                    if(isset($result) && !empty($result['wish_product_id']))
                    {
                        $params = array(
                            'id' => $result['wish_product_id'],
                            'access_token' => $this->accessToken
                        );
                        $tokenResponse = $this->postRequest($path, $params);
                        $request = $tokenResponse['response'];

                        if(isset($request['code']) && $request['code'] == 0) {
                            $this->db->query("UPDATE `". DB_PREFIX ."cedwish_product_variations` SET wish_status = 'Disabled', wish_product_id = '". $result['wish_product_id'] ."' WHERE product_id = '". $product_id ."' ");

                            $variantDisable = $this->disableProductVariants($product_id);

                            return array('success' => true, 'message' => 'Product Disabled On Wish ');
                        } else {
                            return array('success' => false, 'message' => 'Failed To Disable Product On Wish');
                        }
                    } else {
                        return array('success' => false, 'message'=> 'Error While Disabling Product');
                    }

                } catch (Exception $e) {
                    return array('success' => false, 'message' => 'No Response From Wish');
                }
            }
        }
    }

    public function uploadProducts($product_ids = array())
    {
        if (is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0){
            $product_ids = $this->getAllWishProducts();
        }
        if(count($product_ids)) {
            $data = array();
            foreach($product_ids as $key => $product_id){
                $product_id = (int)$product_id;
                try {
                    $product_data_array = $this->prepareWishProduct($product_id);

                    if(!isset($product_data_array['0'])){
                        $temp_product_array = $product_data_array;
                        $product_data_array = array();
                        $product_data_array['0'] = $temp_product_array;
                    }

                    foreach($product_data_array as $product_data)
                    {
                        $validate_data = $this->validateProduct($product_data);
                        if(isset($validate_data) && $validate_data['error'] == '')
                        {
                            if(!empty($product_data['variants'])){
                                $variants = $product_data['variants'];
                            } else {
                                $variants = array();
                            }

                            unset($product_data['variants']);
                            unset($product_data['parent_sku']);
                            $final_data = $this->removeNullValuesFromFinalProducts($product_data);

                            $query = $this->db->query("SELECT wish_product_id FROM `". DB_PREFIX ."cedwish_product_response` WHERE sku = '". $product_data['sku'] ."' ");
                            $result = $query->row;
                            if(!empty($result['wish_product_id']))
                                $data = $this->updateWishProduct($final_data, $variants);
                            else
                                $data = $this->createWishProduct($final_data, $variants);
                        } else {
                            $this->updateProductVariations($product_data['product_id'], $validate_data, $product_data['sku']);
                            return ['success' => false, 'message' => 'Error Validating Product!'];
                        }
                    }
                } catch (Exception $e) {
                    return array('success' => false, 'message' => 'No Response From Wish');
                }
            }
            return $data;
        }
    }

    public function removeNullValuesFromFinalProducts($data = array())
    {
        if (count($data)) {
            foreach ($data as $key => $value) {

                if(!$value || ((string)$value == '0000-00-00') || $value == '0.00' || $value == '0')
                    unset($data[$key]);

                if($key == 'category' || $key == 'description' || $key == 'main_image'){
                    $data['category'] = htmlspecialchars_decode($data['category']);
                    $data['description'] = htmlspecialchars_decode($data['description']);
                    $data['main_image'] = stripslashes($data['main_image']);
                    // $data['main_image'] = 'http://demo.cedcommerce.com/integration/opencart2.0/image/cache/catalog/demo/hp_2-100x100.jpg';
                }

                if($key == 'tags')
                    $data['tags'] = $data['tags'] . ',';
                if(in_array($key,array('mapped_id')))
                    unset($data[$key]);
                if(!empty($key['extra_images']))
                    $data['extra_images'] = stripslashes($data['extra_images']);
            }
        }
        return $data;
    }

    public function createWishProduct($final_data = array(), $variants = array())
    {
        $response = array();
        $path = 'product/add';
        $final_data['parent_sku'] = $final_data['sku'];

        $tokenResponse = $this->postRequest($path, $final_data);
        $request = $tokenResponse['response'];

        if(isset($request['code']) && $request['code'] == 0) {
            $data = $request['data'];
            $wishProductId = $data['Product']['id'];
            $reviewStatus = $data['Product']['review_status'];
            $variantId = $data['Product']['variants']['0']['Variant']['id'];
            //$parentSku = $data['Product']['parent_sku'];
            $sku = $data['Product']['variants']['0']['Variant']['sku'];

            $sql = $this->db->query("SELECT wish_product_id FROM `". DB_PREFIX ."cedwish_product_response` WHERE sku = '". (int)$final_data['sku'] ."' ");
            $res = $sql->row;

            if(!empty($res['wish_product_id']))
                $this->db->query("UPDATE `". DB_PREFIX ."cedwish_product_response` SET `wish_product_id` = '". $this->db->escape($wishProductId) ."', `review_status` = '". $this->db->escape($reviewStatus) ."', `variant_id` = '". $this->db->escape($variantId) ."', `sku` =  '". $this->db->escape($sku) ."', `data` = '". json_encode($data) ."' WHERE wish_product_id = '". (int)$res['wish_product_id'] ."' ");
            else
                $this->db->query("INSERT INTO `". DB_PREFIX ."cedwish_product_response` (`product_id`, `wish_product_id`, `review_status`, `variant_id`, `parent_sku`, `sku`, `data`) VALUES ('". (int)$final_data['product_id'] ."', '". $this->db->escape($wishProductId) ."', '". $this->db->escape($reviewStatus) ."', '". $this->db->escape($variantId) ."', '', '". $this->db->escape($sku) ."', '". json_encode($data) ."') ");

            $this->db->query("UPDATE `". DB_PREFIX ."cedwish_product_variations` SET sku = '". $sku ."' WHERE product_id = '". (int)$final_data['product_id'] ."' ");

            if(count($variants) > '0'){
                $response_array = array();

                foreach($variants as $key => $value){
                    $sql = $this->db->query("SELECT variant_id FROM `". DB_PREFIX ."cedwish_variant_response` WHERE sku = '". $value['sku'] ."' ");
                    $res = $sql->row;

                    $final_variant_data = $this->removeNullValuesFromFinalProducts($value);

                    if(!empty($res['variant_id']))
                        $response = $this->updateProductVariants($final_variant_data);
                    else
                        $response = $this->createProductVariants($final_variant_data);

                    if($response['success'] == '1')
                        $response_array =  ['success' => true, 'message' => $response['message']];
                    else
                        $response_array = ['success' => false, 'message' => $response['message']];
                }
                return $response_array;
            }

            $response = ['success' => true, 'message' => 'Product Created on Wish.'];

        } else {
            $response = ['success' => false, 'message' => $request['message']];
        }
        return $response;
    }

    public function retrieveWishProduct($sku)
    {
        $path = 'product';
        $query = $this->db->query("SELECT wish_product_id FROM `". DB_PREFIX ."cedwish_product_response` WHERE sku = '". $sku ."' ");
        $result = $query->row;

        $id = $result['wish_product_id'];
        $params = array(
            'id' => $id,
            'access_token' => $this->accessToken
        );
        $tokenResponse = $this->getRequest($path, $params);
        $request = $tokenResponse['response'];

        if(isset($request['code']) && $request['code'] == 0) {
            $data = $request['data'];

            return ['success' => true, 'data' => $data];
        } else {
            return ['success' => false, 'message' => $request['message']];
        }
    }

    public function updateWishProduct($final_data = array(), $variants = array())
    {
        $response = array();
        $path = 'product/update';
        if(empty($final_data['parent_sku']))
        {
            $query = $this->db->query("SELECT wish_product_id FROM `". DB_PREFIX ."cedwish_product_response` WHERE sku = '". $final_data['sku'] ."' ");
            $result = $query->row;
            $final_data['id'] = $result['wish_product_id'];
        }

        $tokenResponse = $this->postRequest($path, $final_data);
        $request = $tokenResponse['response'];

        if(isset($request['code']) && $request['code'] == 0) {

            if(count($variants) > '0')
            {
                $response_array = array();
                foreach($variants as $key => $value)
                {
                    $sql = $this->db->query("SELECT variant_id FROM `". DB_PREFIX ."cedwish_variant_response` WHERE sku = '". $value['sku'] ."' ");
                    $res = $sql->row;

                    $final_variant_data = $this->removeNullValuesFromFinalProducts($value);

                    if(!empty($res['variant_id']))
                        $response = $this->updateProductVariants($final_variant_data);
                    else
                        $response = $this->createProductVariants($final_variant_data);

                    if($response['success'] == '1')
                        $response_array =  ['success' => true, 'message' => $response['message']];
                    else
                        $response_array = ['success' => false, 'message' => $response['message']];
                }
                return $response_array;
            }

            $response = ['success' => true, 'message' => 'Product Updated on Wish!'];
        } else {
            $response = ['success' => false, 'message' => $request['message']];
        }
        return $response;
    }

    public function updateProductVariations($product_id, $validate_data, $SkuId)
    {
        $this->db->query(" UPDATE `" . DB_PREFIX . "cedwish_product_variations` SET `error_message` = '" . htmlspecialchars_decode(json_encode($validate_data)) . "' , `sku` = '" .$SkuId. "'  WHERE `product_id` = '" .$product_id. "' ");
        return $product_id;
    }

    public function createProductVariants($final_variant_data = array())
    {
        $response = array();
        $path = 'variant/add';
        $tokenResponse = $this->postRequest($path, $final_variant_data);
        $request = $tokenResponse['response'];

        if(isset($request['code']) && $request['code'] == 0) {
            $data = $request['data'];
            $variantId = $data['Variant']['id'];
            $sku = $data['Variant']['sku'];

            $query = $this->db->query("SELECT profile_id FROM `". DB_PREFIX ."cedwish_product_variations` WHERE product_id = '". $final_variant_data['product_id'] ."' ");
            $result = $query->row;

            $sql = $this->db->query("SELECT variant_id FROM `". DB_PREFIX ."cedwish_variant_response` WHERE sku = '". $sku ."' ");
            $res = $sql->row;

            if(!empty($res['variant_id']))
                $this->db->query("UPDATE `". DB_PREFIX ."cedwish_variant_response` SET variant_id = '". $this->db->escape($variantId) ."', data = '". json_encode($data) ."' WHERE sku = '". $this->db->escape($sku) ."' ");
            else
                $this->db->query("INSERT INTO `". DB_PREFIX ."cedwish_variant_response` (`product_id`, `profile_id`, `parent_sku`, `sku`, `variant_id`, `data`) VALUES ('". (int)$final_variant_data['product_id'] ."', '". (int)$result['profile_id'] ."', '". $this->db->escape($final_variant_data['parent_sku']) ."', '". $this->db->escape($sku) ."', '". $this->db->escape($variantId) ."', '". json_encode($data) ."') ");

            $response = ['success' => true, 'message' => 'Product Variants Created On Wish.'];
        } else {
            $response = ['success' => false, 'message' => $request['message']];
        }
        return $response;
    }

    public function retrieveProductVariants($product_id)
    {
        $path = 'variant';
        $query = $this->db->query("SELECT sku FROM `". DB_PREFIX ."cedwish_variant_response` WHERE product_id = '". $product_id ."' ");
        $result = $query->row;

        $params = array(
            'sku' => $result['sku'],
            'access_token' => $this->accessToken
        );
        $tokenResponse = $this->getRequest($path, $params);
        $request = $tokenResponse['response'];

        if(isset($request['code']) && $request['code'] == 0) {
            $data = $request['data'];

            return ['success' => true, 'data' => $data];
        } else {
            return ['success' => false, 'message' => $request['message']];
        }
    }

    public function updateProductVariants($final_data = array())
    {
        $response = array();
        $path = 'variant/update';

        $tokenResponse = $this->postRequest($path, $final_data);
        $request = $tokenResponse['response'];

        if(isset($request['code']) && $request['code'] == 0) {
            $data = $request['data'];

            $response = ['success' => true, 'message' => 'Product Variants Updated On Wish!'];
        } else {
            $response = ['success' => false, 'message' => $request['message']];
        }
        return $response;
    }

    public function changeVariationSku($sku, $new_sku)
    {
        $response = array();
        $path = 'variant/change-sku';
        $params = array(
            'sku' => $sku,
            'new_sku' => $new_sku,
            'access_token' => $this->accessToken
        );

        $tokenResponse = $this->postRequest($path, $params);
        $request = $tokenResponse['response'];

        if(isset($request['code']) && $request['code'] == 0) {
            $this->db->query("UPDATE `". DB_PREFIX ."cedwish_variant_response` SET sku = '". $this->db->escape($new_sku) ."' WHERE sku = '". $sku ."' ");
            $response = ['success' => true, 'message' => 'Updated Product Variants SKU!'];
        } else {
            $response = ['success' => false, 'message' => $request['message']];
        }
        return $response;
    }

    public function disableProductVariants($product_id)
    {
        $path = 'variant/disable';

        $query = $this->db->query("SELECT sku FROM `". DB_PREFIX ."cedwish_variant_response` WHERE product_id = '". $product_id."' ");
        $result = $query->rows;

        $response = array();
        foreach($result as $key => $value){

            $params = array(
                'sku' => $value['sku'],
                'access_token' => $this->accessToken
            );
            $tokenResponse = $this->postRequest($path, $params);
            $request = $tokenResponse['response'];

            if(isset($request['code']) && $request['code'] == 0) {
                $this->db->query("UPDATE `". DB_PREFIX ."cedwish_variant_response` SET variant_status = 'Disabled' WHERE sku = '". $value['sku'] ."' ");

                $response = ['success' => true, 'message' => 'Product Variants Disabled On Wish!'];
            } else {
                $response = ['success' => false, 'message' => $request['message']];
            }
        }
        return $response;
    }

    public function enableProductVariants($product_id)
    {
        $path = 'variant/enable';

        $query = $this->db->query("SELECT sku FROM `". DB_PREFIX ."cedwish_variant_response` WHERE product_id = '". $product_id."' ");
        $result = $query->rows;

        $response = array();
        foreach($result as $key => $value){

            $params = array(
                'sku' => $value['sku'],
                'access_token' => $this->accessToken
            );
            $tokenResponse = $this->postRequest($path, $params);
            $request = $tokenResponse['response'];

            if(isset($request['code']) && $request['code'] == 0) {
                $this->db->query("UPDATE `". DB_PREFIX ."cedwish_variant_response` SET variant_status = 'Enabled' WHERE sku = '". $value['sku'] ."' ");

                $response = ['success' => true, 'message' => 'Product Variants Enabled On Wish!'];
            } else {
                $response = ['success' => false, 'message' => $request['message']];
            }
        }
        return $response;
    }


    public function getAllMappedProducts(){

        $query = $this->db->query("SELECT product_id FROM `" . DB_PREFIX . "cedwish_product_variations` ");
        $result = $query->rows;
        $product_ids = array();
        if(is_array($result) && count($result)) {
            foreach ($result as $key => $value) {
                if (isset($value['product_id']) && $value['product_id']) {
                    $product_ids[] = $value['product_id'];
                }
            }
        }
        return $product_ids;
    }

    public function getAllWishProducts()
    {
        $result = $this->db->query("SELECT category FROM `" . DB_PREFIX . "cedwish_mapping_details`");
        if ($result && $result->num_rows) {
            $product_ids = array();
            $categories_mapped =array();
            foreach ($result->rows as $key => $store_category) {
                $categories_mapped = array_merge($categories_mapped, json_decode($store_category['category'], true));
            }

            if(count($categories_mapped)){
                $categories_mapped = array_unique($categories_mapped);
                $results = $this->db->query("SELECT product_id FROM `".DB_PREFIX."product_to_category` WHERE category_id IN (".implode(',', $categories_mapped).")");

                if ($results->num_rows) {
                    foreach ($results->rows as $key => $value) {
                        $product_ids[] =  $value['product_id'];
                    }
                }
                return $product_ids;
            }
            return array();
        } else {
            return array();
        }
    }
    public function prepareWishProduct($product_id)
    {
        $product_id = (int)$product_id;

        if($product_id)
        {
            $query = $this->db->query("SELECT profile_id FROM `". DB_PREFIX ."cedwish_product_variations` WHERE `product_id` = '".(int)$product_id."' ");
            $result = $query->row;

            if(isset($result) && isset($result['profile_id']))
            {
                $profile_id = (int)$result['profile_id'];
                $fetched_mapped_data = $this->db->query("SELECT * FROM `" . DB_PREFIX . "cedwish_mapping_details` WHERE `mapped_id` = '" . $profile_id . "' ");
                $mapped_data = $fetched_mapped_data->row;

                $wish_array = array();
                if(isset($mapped_data) && $mapped_data)
                {
                    $attribute_array = json_decode($mapped_data['attribute'], true);
                    $variant_array   = json_decode($mapped_data['variant_attribute'], true);
                    $default_array   = json_decode($mapped_data['default_attribute'], true);
                    if(!is_array($attribute_array) || empty($attribute_array))
                    {
                        $attribute_array = array();
                    }
                    if(!is_array($variant_array) || empty($variant_array))
                    {
                        $variant_array = array();
                    }
                    if(!is_array($default_array) || empty($default_array))
                    {
                        $default_array = array();
                    }

                    // Wish Category Name
                    if(isset($mapped_data['CategoryName']) && $mapped_data['CategoryName'])
                        $wish_array['category'] = $mapped_data['CategoryName'];
                    else
                        $wish_array['category'] = '';

                    // Attributes
                    if(isset($attribute_array) && !empty($attribute_array)){
                        foreach ($attribute_array as $key => $value) {
                            $attribute = '';
                            $attribute_id = 0;

                            $explode_res = explode('-', $value);
                            $attribute = $explode_res[0];
                            @$attribute_id = $explode_res[1];

                            // Attributes (Variants)
                            if($attribute == "attri"){
                                $query = $this->db->query("SELECT `text` FROM `" . DB_PREFIX . "product_attribute` WHERE product_id = '" . $product_id . "' AND attribute_id = '" . $attribute_id . "' ");
                                $attri_result = $query->row;

                                if(!empty($attri_result)){
                                    $wish_array[$key]   = $attri_result['text'];
                                } else {
                                    $wish_array[$key] = '';
                                }
                            }
                            // System Default
                            if($attribute == "system_default"){

                                $query = $this->db->query("SELECT field_name FROM `" . DB_PREFIX ."cedwish_system_default` WHERE id = '" .$attribute_id. "' ");
                                $result = $query->row;

                                $system_result = $this->getSystemDefaultDetailFromProduct($product_id);

                                if(!empty($system_result)){
                                    $wish_array[$key]   = $system_result[$result['field_name']];
                                } else {
                                    $wish_array[$key] = '';
                                }
                            }
                        }
                    }

                    // Variant Attributes
                    $combination_array = array();
                    if(isset($variant_array) && !empty($variant_array))
                    {
                        $combination = $this->productOptionCombination($product_id, $profile_id);

                        if(!empty($combination))
                        {
                            foreach ($combination as $key1 => $val)
                            {
                                $option_data = array();
                                $quantity_array = array();

                                foreach($variant_array as $key => $value)
                                {
                                    $explode_res = explode('-', $value);
                                    $option_id = @$explode_res[1];
                                    $price = $wish_array['price'];
                                    foreach($val as $key2 => $key2_value){

                                        $option_value_query = $this->db->query("SELECT pov.quantity, pov.price_prefix, pov.price, p.tax_class_id FROM `". DB_PREFIX ."option_value_description` AS ovd JOIN `". DB_PREFIX ."product_option_value` AS pov ON (ovd.option_value_id = pov.option_value_id) JOIN `" . DB_PREFIX . "product` AS p ON (p.product_id = pov.product_id) WHERE ovd.option_id = '". $key2 ."' AND ovd.name = '". $key2_value ."' AND pov.product_id = '". $product_id ."' ");
                                        $option_value_res = $option_value_query->row;

                                        if(isset($option_value_res['quantity']) && $option_value_res['quantity'])
                                            $quantity_array[] = $option_value_res['quantity'];

                                        if(isset($option_value_res['price']) && $option_value_res['price'])
                                        {
                                            if($option_value_res['price_prefix'] == '+')
                                                @$price +=(float)$option_value_res['price'];
                                            elseif($option_value_res['price_prefix'] == '-')
                                                @$price -=(float)$option_value_res['price'];

                                            // if(!empty($option_value_res['tax_class_id'])){
                                            //   $price_with_tax = $this->tax->getTax($price, $option_value_res['tax_class_id']);
                                            //   $price_with_tax += $price;
                                            // }
                                        }

                                        //@$quantity=$option_value_res['quantity'];

                                        if(isset($val['sku']))
                                            $option_data['sku'] = $val['sku'];
                                        if(isset($option_value_res) && !empty($option_value_res['quantity']))
                                        {
                                            $option_data['price'] = $price;
                                        }
                                        if(isset($val[$option_id]))
                                            $option_data[$key] = $val[$option_id];
                                        else
                                            $option_data[$key]   = '';

                                    }
                                    $option_data['inventory'] = min($quantity_array);
                                }
                                $combination_array[$key1] = $option_data;
                            }
                        } else {
                            foreach($variant_array as $key => $value)
                            {
                                $wish_array[$key] = '';
                            }
                        }
                    }

                    // Default Attribute
                    if(isset($default_array) && !empty($default_array)){

                        if(empty($wish_array['tags']))
                            $wish_array['tags']      = $default_array['tags'];
                        if(empty($wish_array['inventory']))
                            $wish_array['inventory'] = $default_array['inventory'];
                        if(empty($wish_array['shipping']))
                            $wish_array['shipping']  = $default_array['shipping'];
                        // echo '<pre>'; print_r($wish_array); die;
                        $wish_array['msrp']    = $default_array['msrp'];
                        $wish_array['shipping_time']  = $default_array['shipping_time'];
                        $wish_array['brand']   = $default_array['brand'];
                        $wish_array['landing_page_url']  = $default_array['landing_page_url'];
                        $wish_array['upc']     = $default_array['upc'];
                        $wish_array['max_quantity']  = $default_array['max_quantity'];
                        $wish_array['length']  = $default_array['length'];
                        $wish_array['width']   = $default_array['width'];
                        $wish_array['height']  = $default_array['height'];
                        $wish_array['weight']  = $default_array['weight'];
                        $wish_array['declared_value'] = $default_array['declared_value'];
                        $wish_array['hscode']  = $default_array['hscode'];

                        foreach($default_array as $key => $value) {

                            $explode_res = explode('-', $value);
                            $id = @$explode_res[1];

                            // Country
                            if($key == "origin_country"){
                                $query = $this->db->query("SELECT iso_code_2 FROM `" . DB_PREFIX ."country` WHERE country_id = '" .$id. "' ");
                                $result = $query->row;
                                $wish_array['origin_country']   = $result['iso_code_2'];
                            }
                            // HasPowder
                            if(($key == "has_powder" || $key == "has_liquid" || $key == "has_metal" || $key == "has_battery") && $id == '0'){
                                $wish_array[$key] = '0';
                            }
                            //HasPowder
                            if(($key == "has_powder" || $key == "has_liquid" || $key == "has_metal" || $key == "has_battery") && $id == '1'){
                                $wish_array[$key] = '1';
                            }
                        }
                    }

                    $query = $this->db->query("SELECT model AS sku, price, image FROM `" . DB_PREFIX . "product` WHERE product_id = '" . $product_id . "' ");
                    $res = $query->row;

                    if(empty($wish_array['sku'])){
                        $wish_array['sku'] = $res['sku'];
                        $wish_array['parent_sku'] = $res['sku'];
                    } else {
                        $wish_array['parent_sku'] = $res['sku'];
                    }
                    // if(empty($wish_array['pieces']))
                    //  $wish_array['pieces'] = $wish_array['pieces'];

                    $wish_array['product_id'] = $product_id;
                    $wish_array['main_image'] = $res['image'];

                    if(isset($res['image']) && $res['image'])
                        $wish_array['main_image'] = HTTPS_CATALOG . "image/" . $res['image'];
                    else
                        $wish_array['main_image'] = '';

                    $query = $this->db->query("SELECT image FROM `" . DB_PREFIX . "product_image` WHERE product_id = '" . $product_id . "' ");
                    $image = $query->rows;

                    if(isset($image['image']) && $image['image'])
                        $wish_array['extra_images'] = HTTPS_CATALOG . "image/" . $image['image'];
                    else
                        $wish_array['extra_images'] = '';

                    $wish_array['access_token'] =  $this->accessToken;

                    if(isset($combination_array) && !empty($combination_array)){
                        $temp_variant_array = array();
                        foreach ($combination_array as $key => $value) {
                            $temp_variant_array[] = array_merge($wish_array, $value);
                        }
                        $wish_array['variants'] = $temp_variant_array;
                    }
                    //echo '<pre>'; print_r($wish_array); die();
                }

                if(count($wish_array))
                    return $wish_array;
                return array('error_message' => 'Product Id Not Found.');
            }
        }
        return array('error_message' => 'Product Id Not Found.');
    }

    public function getSystemDefaultDetailFromProduct($product_id)
    {
        $product_id = (int)$product_id;

        $query = $this->db->query("SELECT p.model,p.upc, p.ean, p.quantity, p.price AS price_for_tax, p.tax_class_id, p.model, pd.name, pd.description, pd.meta_title, pd.meta_description, m.name AS manufacturer FROM `" . DB_PREFIX . "product` AS p JOIN `" . DB_PREFIX . "product_description` AS pd ON (pd.product_id = p.product_id) JOIN `" . DB_PREFIX . "manufacturer` AS m ON (p.manufacturer_id = m.manufacturer_id) WHERE p.product_id = '" . $product_id . "' ");
        //  ss.name AS stock_status JOIN `" . DB_PREFIX . "stock_status` AS ss ON (p.stock_status_id = ss.stock_status_id)
        $result = $query->row;

        if(isset($result['tax_class_id']) && !empty($result['tax_class_id'])){
            $sql = $this->db->query("SELECT tra.rate AS tax_rule FROM `" . DB_PREFIX . "tax_rule` AS tru JOIN `" . DB_PREFIX . "tax_rate` AS tra ON (tru.tax_rate_id = tra.tax_rate_id) WHERE tru.tax_class_id = '" . $result['tax_class_id'] . "' ");
            $tax_result = $sql->row;

            if(isset($tax_result) && !empty($tax_result))
                $tax_rule = $tax_result['tax_rule'];
            else
                $tax_rule = '0';
            $price_for_tax = $this->tax->getTax($result['price_for_tax'], $result['tax_class_id']);
        }
        $price = (float) $this->getWishProductPrice($product_id);
        // Model
        if(isset($result['model']) && !empty($result['model']))
            $model = $result['model'];
        else
            $model = '0';
        // UPC
        if(isset($result['upc']) && !empty($result['upc']))
            $upc = $result['upc'];
        elseif(isset($result['model']) && !empty($result['model']))
            $upc = $result['model'];
        else
            $upc = '0';
        // EAN
        if(isset($result['ean']) && !empty($result['ean']))
            $ean = $result['ean'];
        elseif(isset($result['model']) && !empty($result['model']))
            $ean = $result['model'];
        else
            $ean = '0';
        // Short Description
        if(isset($result['meta_description']) && !empty($result['meta_description']))
            $short_description = $result['meta_description'];
        elseif(isset($result['description']) && !empty($result['description']))
            $short_description = $result['description'];
        else
            $short_description = '';
        // Quantity
        if(isset($result['quantity']) && !empty($result['quantity']))
            $quantity = $result['quantity'];
        else
            $quantity = '0';
        // Price With Tax
        if(isset($price_for_tax) && !empty($price_for_tax))
            $price_with_tax = $price_for_tax;
        elseif(isset($result['price']) && !empty($result['price']))
            $price_with_tax = $result['price'];
        else
            $price_with_tax = '0';
        // Price w/o Tax
        if(isset($price) && !empty($price))
            $price_wo_tax = $price;
        elseif(isset($result['price']) && !empty($result['price']))
            $price_wo_tax = $result['price'];
        else
            $price_wo_tax = '0';
        // Name
        if(isset($result['name']) && !empty($result['name']))
            $name = $result['name'];
        elseif(isset($result['meta_title']) && !empty($result['meta_title']))
            $name = $result['meta_title'];
        else
            $name = '';
        // Description
        if(isset($result['description']) && !empty($result['description']))
            $description = $result['description'];
        elseif(isset($result['meta_description']) && !empty($result['meta_description']))
            $description = $result['meta_description'];
        else
            $description = '';
        // Manufacturer
        if(isset($result['manufacturer']) && !empty($result['manufacturer']))
            $manufacturer = $result['manufacturer'];
        elseif(isset($result['meta_title']) && !empty($result['meta_title']))
            $manufacturer = $result['meta_title'];
        else
            $manufacturer = '';
        // Stock Status
        // if(isset($result['stock_status']) && !empty($result['stock_status']))
        //   $stock_status = $result['stock_status'];
        // else
        //   $stock_status = '0';

        return array(
            'model' => $model,
            'upc' => $upc,
            'ean' => $ean,
            'quantity' => $quantity,
            'price_with_tax' =>  $price_with_tax,
            'price' => $price_wo_tax,
            'name' => $name,
            'description' => $description,
            'short_description' => $short_description,
            'manufacturer' => $manufacturer,
            'tax_rule' => isset($tax_rule)?$tax_rule:'0'
            // 'stock_status' => $stock_status
        );
    }

    public function getWishProductPrice($product_id)
    {
        if($product_id) {
            $wish_price = 0;
            $price_variation_type = $this->config->get('ced_wish_product_price');
            if(!empty($this->config->get('ced_wish_product_price_fixed')))
                $price_variation_type_ampount =(float) $this->config->get('ced_wish_product_price_fixed');
            else
                $price_variation_type_ampount =(float) $this->config->get('ced_wish_product_price_percentage');

            switch ($price_variation_type) {
                case '1':   // regular
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $wish_price = $price;
                    break;

                case 'special':
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "' AND ((date_start = '0000-00-00' OR date_start < NOW()) AND (date_end = '0000-00-00' OR date_end > NOW())) ORDER BY priority ASC, price ASC");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $wish_price = $price;
                    break;

                case '2':   // increase_by_amount
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $wish_price = $price + $price_variation_type_ampount;
                    break;

                case '3':  // decrease_by_amount
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $wish_price = $price - $price_variation_type_ampount;
                    break;

                case '4':  // increase_by_percent
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $wish_price = $price + ($price * $price_variation_type_ampount)/100;
                    break;

                case '5':   // decrease_by_percent
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $wish_price = $price - ($price * $price_variation_type_ampount)/100;
                    break;

                default:
                    $price = 0 ;
                    $query = $this->db->query("SELECT `price` FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
                    if($query->num_rows)
                        $price = $query->row['price'];
                    $wish_price = $price;
                    break;
            }
            return $wish_price ;
        }
        return 0;
    }

    public function productOptionCombination($product_id, $profile_id=0)
    {
        $product_id = (int)$product_id;
        $profile_id = (int)$profile_id;
        $product_variations = array();
        $product_options = $this->getProductOptionsValue($product_id, $profile_id);
        $variants = array();
        $array_combination=array();
        $op_count=0;

        foreach ($product_options as $key => $value)
        {
            if(isset($value['option_id']) && $value['option_id']!="")
            {
                if(isset($value['option_id']) && in_array(trim($value['option_name']),array('Select','Radio','Checkbox','Size')))
                {
                    foreach ($value['product_option_value'] as $keys => $val)
                    {
                        if(isset($val['option_value_id']) && $val['option_value_id']!=""){
                            $variants[$op_count]=$value['option_id'];
                            $array_combination[$op_count][]=$val['option_value_name'];
                        }
                    }
                    $op_count++;
                }
            }
        }

        if(empty($array_combination)){
            @$option_id   = $product_options[0]['option_id'];
            @$option_name = $product_options[0]['option_name'];
            @$product_option_value = $product_options[0]['product_option_value'];

            if(isset($option_id) && in_array(trim($option_name),array('Select','Radio','Checkbox','Size', 'Colour')))
            {
                foreach ($product_option_value as $keys => $val)
                {
                    if(isset($val['option_value_id']) && $val['option_value_id']!=""){
                        $variants[$op_count]=$option_id;
                        $array_combination[$op_count][]=$val['option_value_name'];
                    }
                }
            }
        }

        $matrix_options=$this->combinations($array_combination);
        $matrixarray=array();
        $matrix=array();
        $opt_val_id = '0';
        $option_array = array();
        foreach ($product_options as $key => $value)
        {
            foreach ($value['product_option_value'] as $keys => $val)
            {
                $opt_val = $val['option_value_id'];
                $option_array[$opt_val]=$val['option_value_name'];
            }
            $opt_val_id++;
        }

        if(count($variants)=='1'){
            $this->db->query("DELETE FROM `". DB_PREFIX."cedwish_product_attribute_combination` WHERE product_id = '". $product_id ."' AND profile_id = '". $profile_id ."' ");
            // $this->db->query("DELETE FROM `" . DB_PREFIX . "cedwish_final_products` WHERE product_id = '". $product_id."' ");

            foreach ($matrix_options as $key => $value) {
                $query = $this->db->query("SELECT model AS sku FROM `". DB_PREFIX."product` WHERE product_id = '". $product_id ."' ");
                $sku_id = $query->row;

                if(!empty($option_array)){
                    $random_no = '';
                    foreach($option_array as $key2 => $val2){
                        if(in_array($val2,array($value)))
                            $random_no .= $key2;
                    }
                }

                //$random_no = substr(str_shuffle('0123456789'), 0, 4);
                $sku = $sku_id['sku'] . '-' . $random_no;

                $matrixarray[]=array($variants['0']=>$value, 'sku'=>$sku);

                $this->db->query("INSERT INTO `". DB_PREFIX ."cedwish_product_attribute_combination` SET product_id = '". $product_id ."', profile_id = '" . $profile_id . "', SkuId = '". $sku ."', combination = '". json_encode($value) ."' ");
            }
        } else {
            $this->db->query("DELETE FROM `". DB_PREFIX."cedwish_product_attribute_combination` WHERE product_id = '". $product_id ."' AND profile_id = '". $profile_id ."' ");
            // $this->db->query("DELETE FROM `" . DB_PREFIX . "cedwish_final_products` WHERE product_id = '". $product_id."' ");

            foreach ($matrix_options as $key1 => $value) {
                if(is_array($value) && count($value)>0){
                    $query = $this->db->query("SELECT model AS sku FROM `". DB_PREFIX."product` WHERE product_id = '". $product_id ."' ");
                    $sku_id = $query->row;

                    if(!empty($option_array)){
                        $random_no = '';
                        foreach($option_array as $key2 => $val2){
                            if(in_array($val2,$value))
                                $random_no .= $key2;
                        }
                    }
                    //$random_no = substr(str_shuffle('0123456789'), 0, 4);
                    $sku = $sku_id['sku'] . '-' . $random_no;

                    foreach ($value as $key => $val) {
                        $matrix[$variants[$key]]= $val;
                        $matrix['sku'] = $sku;
                    }

                    $this->db->query("INSERT INTO `". DB_PREFIX ."cedwish_product_attribute_combination` SET product_id = '". $product_id ."', profile_id = '" . $profile_id . "', SkuId = '". $sku ."', combination = '". json_encode($matrix) ."' ");

                    $matrixarray[]=$matrix;

                } else {
                    $matrixarray[$variants['0']]=$matrix_options;
                }
            }
        }
        return $matrixarray;
    }

    public function combinations($arrays, $i = 0) {

        if (!isset($arrays[$i])) {
            return array();
        }
        if ($i == count($arrays) - 1) {
            return $arrays[$i];
        }
        $tmp = $this->combinations($arrays, $i + 1);

        $result = array();
        foreach ($arrays[$i] as $v) {
            foreach ($tmp as $t) {
                $result[] = is_array($t) ? array_merge(array($v), $t) : array($v, $t);
            }
        }
        return $result;
    }

    public function getProductOptionsValue($product_id, $profile_id)
    {
        $product_id = (int)$product_id;
        $profile_id = (int)$profile_id;
        $product_option_data = array();

        $profile_attributes_query = $this->db->query("SELECT variant_attribute FROM `". DB_PREFIX ."cedwish_mapping_details` WHERE `mapped_id` = '". $profile_id ."' ");
        $profile_attributes = $profile_attributes_query->row;
        $option_id_array = array();

        if(isset($profile_attributes) && !empty($profile_attributes)){
            $variant_array = json_decode($profile_attributes['variant_attribute'], true);
            if(!is_array($variant_array) || empty($variant_array))
            {
                $variant_array = array();
            }
            $product_option_data = array();
            foreach ($variant_array as $key2 => $value) {
                $explode_res = explode('-', $value);
                $option_id = @$explode_res[1];
                $option_id_array[] = $option_id;
            }
        }

        $product_option_query = $this->db->query("SELECT po.product_option_id, od.option_id, od.name AS option_name FROM `". DB_PREFIX ."product_option` AS po JOIN `". DB_PREFIX ."option_description` AS od ON (po.option_id = od.option_id) WHERE po.product_id = '". $product_id ."' ");

        $product_option_result = $product_option_query->rows;

        foreach($product_option_result as $key => $product_option_array){
            if(isset($product_option_array) && in_array(trim($product_option_array['option_id']), $option_id_array))
            {
                $product_option_value_data = array();

                $product_option_value_query = $this->db->query("SELECT pov.product_option_value_id, pov.option_value_id, pov.quantity, pov.price, ovd.name AS option_value_name FROM `". DB_PREFIX ."product_option_value` AS pov JOIN `". DB_PREFIX ."option_value_description` AS ovd ON (pov.option_value_id = ovd.option_value_id) WHERE pov.product_id = '". $product_id ."' AND pov.product_option_id = '". $product_option_array['product_option_id'] ."' ");
                $product_option_value_result = $product_option_value_query->rows;

                foreach($product_option_value_result as $key1 => $product_option_value_array){

                    $product_option_value_data[] = array(
                        'product_option_value_id' => $product_option_value_array['product_option_value_id'],
                        'option_value_id' => $product_option_value_array['option_value_id'],
                        'option_value_name' => $product_option_value_array['option_value_name'],
                        'quantity' => $product_option_value_array['quantity'],
                        'price' => $product_option_value_array['price'],
                    );
                }

                $product_option_data[] = array(
                    'product_option_id' => $product_option_array['product_option_id'],
                    'product_option_value' => $product_option_value_data,
                    'option_id' => $product_option_array['option_id'],
                    'option_name' =>$product_option_array['option_name']

                );
            }
        }
        return $product_option_data;
    }

    public function fetchOrders($order)
    {
        //$response = array();
        $path = 'order/get-fulfill';
        $params = array(
            'access_token' => $this->accessToken
        );

        $tokenResponse = $this->postRequest($path, $params);
        $request = $tokenResponse['response'];

//        $paging = $request['paging'];
//
//        if(isset($paging) && !empty($paging['next'])){
//
//            $page_url = explode('=', $paging['next']);
//            @$start = $page_url[1];
//
//            $params = array(
//                'start' => $start,
//                'access_token' => $this->accessToken
//            );
//
//            $pageResponse = $this->postRequest($path, $params);
//            $pagerequest = $pageResponse['response'];
//        }

        //$this->log($response);
        try {
            $errorMessage= '';
            if ($request) {
                if (isset($request['code']) && $request['code'] == 0) {
                    if (isset($request['data']) && $request['data']) {

                        $message = $request['message'];
                        $data = $request['data'];
                        //$response = $this->xml2array($message);

                        if (!is_array($data)) {
                            return array('success' => false ,'message' => $message);
                        }
                        $errorMessage = '';
                        if (isset($message) && !empty($message)) {
                            $errorMessage  =  $message;
                            // foreach ($response['errors'] as $key => $error)
                            // {
                            //    foreach ($error as $key => $err) {
                            //       if (isset($err['description']) && $err['  description']) {
                            //           $errorMessage .= $err['description'];
                            //       }
                            //     }
                            // }

                        } else {
                            $order_ids = array();

                            if(is_array($data) && isset($data) && count($data))
                            {
                                // if(is_array($fetchedOrders) && isset($fetchedOrders['o:order']) && count($fetchedOrders['o:order'])) {

                                if(!isset($data['0'])){
                                    $temp_orderLine = $data;
                                    $data = array();
                                    $data['0'] = $temp_orderLine;
                                }
                                $totalOrderFetched = count($data);

                                foreach($data as $key => $value) {
                                    $fetchedOrders = $value['Order'];
                                    //echo '<pre>'; print_r($value);  die;
                                    if(isset($fetchedOrders['order_id']) && $fetchedOrders['order_id']) {
                                        $wish_order_id = $fetchedOrders['order_id'];
                                        $already_exist = $this->isWishOrderIdExist($wish_order_id);
                                        //echo '<pre>'; print_r($already_exist);  die;
                                        if($already_exist) {
                                            continue;
                                        } else {

                                            $order_ids[]=$this->prepareOrderData($fetchedOrders);

                                            $this->log(json_encode($fetchedOrders),'6',true);

                                            $order_ids = array_filter($order_ids);
                                            // for auto accept and reject
                                            // if ($this->config->get('ced_wish_auto_accept_reject')) {
                                            //   $this->acceptOrder($wish_order_id,'order/accept');
                                            // }
                                        }
                                    }
                                }
                                $totalOrderPrepared = count($order_ids);

                                if($totalOrderPrepared == $totalOrderFetched) {
                                    return array('success' => true ,'message' => $order_ids);
                                } else if($totalOrderPrepared && ($totalOrderFetched > count($order_ids))) {
                                    return array('success' => true ,'message' => $order_ids,'sub_message' => 'Please see Rejected List too.');
                                } else if($totalOrderPrepared==0) {
                                    return array('success' => true ,'message' => 'No new Order Found.');
                                } else {
                                    return array('success' => false ,'message' => 'Order Send to Rejected List.');
                                }

                            } else {
                                return array('success' => true ,'message' => 'No new order found.');
                            }
                            //}
                            // }

                        }
                    }
                    if ($errorMessage) {
                        return array('success' => false ,'message' => $errorMessage);
                    }
                } else {

                    return array('success' => false ,'message' => $request['message']);
                }
            } else {
                return array('success' => false ,'message' =>$this->language->get('error_module'));
            }
        }
        catch(Exception $e) {
            $this->log('Order Error:  ' . var_export($request, true));
            $this->log('Order Error Message : ' .$e->getMessage());
            return array('success' => false ,'message' => $e->getMessage());
        }
    }

    public function isWishOrderIdExist($wish_order_id=0) {

        $isExist = false ;
        if ($wish_order_id) {
            $sql = "SELECT `id` FROM `" . DB_PREFIX . "cedwish_order` WHERE `wish_order_id` = '".$wish_order_id."'";

            $result = $this->db->query($sql);

            if ($result->num_rows) {
                $isExist = true ;
            }
        }

        return $isExist;
    }

    public function prepareOrderData( $data = array()) {
        if($data) {
            $opencart_order_id = 0;
            $wish_order_id = $data['order_id'];

            if (!$this->isWishOrderIdExist($wish_order_id)) {
                $order_id = $this->createWishOrder($data);
                if($order_id)
                    return $order_id;
            }
        }
    }

    public function createWishOrder($data) {

        $order_data   = array();

        $shippingDate        = $data['expected_ship_date'];
        $quantity            = $data['quantity'];
        $variantId           = $data['variant_id'];

        if(isset($data['ShippingDetail']) && count($data['ShippingDetail']))
        {
            $shippingAddress = $data['ShippingDetail'];
            $name = explode(' ', $shippingAddress['name']);
            $firstName    = $name[0];
            $lastName     = $name[1];
            $streetAddress= $shippingAddress['street_address1'];
            $city         = $shippingAddress['city'];
            $state        = $shippingAddress['state'];
            $postalCode   = $shippingAddress['zipcode'];
            $countryCode  = $shippingAddress['country'];
            $phoneNumber  = $shippingAddress['phone_number'];
        }

        $cost                = $data['cost'];
        $shippingCost        = $data['shipping_cost'];
        $skuId               = $data['sku'];
        $grandtotal         = $data['order_total'];
        $wishProductId       = $data['product_id'];
        $productImageUrl     = $data['product_image_url'];
        //$orderPrefix         = $this->config->get('ced_wish_order_id_prefix');
        $orderId             = $data['order_id'];
        $orderStatus         = $data['state'];
        $orderDate           = $data['order_time'];
        $productName         = $data['product_name'];
        $transactionID       = $data['transaction_id'];
        $customerOrderId     = $data['buyer_id'];
        $email               = $this->config->get('ced_wish_default_customer_email');
        if(empty($email))
            $email             = $orderId.'@cedwishcustomer.com';

        // Order Array
        $order_data['invoice_prefix']     = $this->config->get('config_invoice_prefix');
        $order_data['store_id']           = $this->config->get('config_store');
        $order_data['store_name']         = $this->config->get('config_name');
        $order_data['store_url']          = HTTPS_SERVER;
        $order_data['customer_id']        = $customerOrderId;
        $order_data['customer_group_id']  = '1';
        $order_data['firstname']          = $firstName;
        $order_data['lastname']           = $lastName;
        $order_data['email']              = $email;
        $order_data['telephone']          = $phoneNumber;
        $order_data['fax']                = '';
        $order_data['custom_field']       = array();

        // Payment Detail
        $order_data['payment_firstname']  = $firstName;
        $order_data['payment_lastname']   = $lastName;
        $order_data['payment_company']    = '';
        $order_data['payment_address_1']  = $streetAddress;
        $order_data['payment_address_2']  = '';
        $order_data['payment_city']       = $city;
        $order_data['payment_postcode']   = $postalCode;
        $state_info = $this->getOpencartZoneByWishZoneCode($state);
        $order_data['payment_zone']       = isset($state)? $state : '';
        $order_data['payment_zone_id']    = isset($state_info['zone_id'])? $state_info['zone_id'] :'0';
        $country_info = $this->getOpencartCountryByWishCountryCode($countryCode);
        $order_data['payment_country']        = isset($country_info['name'])? $country_info['name'] :'';
        $order_data['payment_country_id']     = isset($country_info['country_id'])? $country_info['country_id'] :'0';
        $order_data['payment_address_format'] = '';
        $order_data['payment_custom_field']   = array();
        $order_data['payment_method']         = 'Wish Payment';
        $order_data['payment_code']           = 'WishPayment';
        //$language_info = $this->getOpencartLanguageByWishLanguageCode($customerLanguageCode);
        $order_data['payment_language']       = '';
        $order_data['payment_language_id']    = '0';
        // $currency_info = $this->getOpencartCurrencyByWishCurrencyCode($currencyCode);
        $order_data['payment_currency']       = '';
        $order_data['payment_currency_id']    = '0';

        // Shipping Detail
        $order_data['shipping_firstname']         = $firstName;
        $order_data['shipping_lastname']          = $lastName;
        $order_data['shipping_company']           = '';
        $order_data['shipping_address_1']         = $streetAddress;
        $order_data['shipping_address_2']         = '';
        $order_data['shipping_city']              = $city;
        $order_data['shipping_postcode']          = $postalCode;
        $order_data['shipping_zone']              = isset($state)? $state : '';
        $order_data['shipping_zone_id']           = isset($state_info['zone_id'])? $state_info['zone_id'] :'0';
        $order_data['shipping_country']           = isset($country_info['name'])? $country_info['name'] :'';
        $order_data['shipping_country_id']        = isset($country_info['country_id'])? $country_info['country_id'] :'0';
        $order_data['shipping_address_format']    = '';
        $order_data['shipping_custom_field']      = array( );
        $order_data['shipping_method']            = 'Wish Shipping';
        $order_data['shipping_code']              = 'WishShipping.WishShipping';

        // for products
        $total_price = isset($cost) ? $cost : 0;
        $total_shipping_cost = isset($shippingCost) ? $shippingCost : 0;

        $ordered_products = $this->getOpencartProductBySku($wishProductId, $skuId, $quantity, $orderId, $productName, $cost, $shippingCost, $data);

        if($ordered_products)
            $order_data['products'][] = $ordered_products;


        if(isset($order_data['products']) && count($order_data['products'])>0)
        {
            $order_data['vouchers']=array();

            $order_data['totals'][]= array(
                'code' => 'sub_total',
                'title' => 'Sub-Total',
                'value'=>$total_price,
                'sort_order' => 1
            );

            $order_data['totals'][]= array(
                'code' => 'shipping',
                'title' => 'Wish Shipping',
                'value'=>(float) $total_shipping_cost,
                'sort_order' => 3
            );

            $order_data['totals'][]= array(
                'code' => 'total',
                'title' => 'Total',
                'value'=> (float) $grandtotal,
                'sort_order' => 9
            );

            $order_data['comment']='';
            $order_data['total']= (float) $grandtotal;
            $order_data['affiliate_id']='0';
            $order_data['commission']='0';
            $order_data['marketing_id']='0';
            $order_data['tracking']='';
            $order_data['language_id'] = $this->config->get('config_language_id');

            if (isset($this->session->data['currency']) && $this->session->data['currency']) {
                $order_data['currency_id'] = $this->currency->getId($this->session->data['currency']);
                $order_data['currency_code'] = $this->session->data['currency'];
                $order_data['currency_value'] = $this->currency->getValue($this->session->data['currency']);
            } else {
                $order_data['currency_id'] = $this->currency->getId($this->config->get('config_currency'));
                $order_data['currency_code'] = $this->config->get('config_currency');
                $order_data['currency_value'] = $this->currency->getValue($this->config->get('config_currency'));
            }

            $order_data['ip'] = '';
            $order_data['forwarded_ip'] = '';
            $order_data['user_agent'] = '';
            $order_data['accept_language'] = '';

            $store_order_id = $this->addWishOrder($order_data);
            $query = $this->db->query("SELECT count(wish_order_id) AS wish_order_id FROM `" . DB_PREFIX . "cedwish_order` WHERE sku = '". $skuId ."' ");
            $result = $query->row;
            if($result['wish_order_id'] > '0'){
                $respo = $this->db->query("UPDATE " . DB_PREFIX . "cedwish_order SET store_order_id =  '" . (int)$store_order_id . "', wish_order_id='".$orderId."', `wish_product_id` = '". $this->db->escape($wishProductId) ."', `variant_id` = '". $this->db->escape($variantId) ."' , wish_status = '". $this->db->escape($orderStatus) ."', order_data = '". $this->db->escape(json_encode($data)) ."', `order_place_date` = '" . $this->db->escape($orderDate) . "', `product_image_url` = '". $this->db->escape($productImageUrl) ."', `shipping_detail` = '" . $this->db->escape(json_encode($data['ShippingDetail'])) . "' WHERE sku = '". $skuId ."' ");
                $this->db->query("UPDATE `" . DB_PREFIX . "cedwish_order_error` SET store_order_id = '". $store_order_id ."' WHERE sku = '". $skuId ."' AND wish_order_id = '".$orderId."' ");
            } else {
                $respo = $this->db->query("INSERT INTO " . DB_PREFIX . "cedwish_order SET store_order_id =  '" . (int)$store_order_id . "', wish_order_id='".$orderId."', `wish_product_id` = '". $this->db->escape($wishProductId) ."', `variant_id` = '". $this->db->escape($variantId) ."' , sku = '". $this->db->escape($skuId) ."', wish_status = '". $this->db->escape($orderStatus) ."', order_data = '". $this->db->escape(json_encode($data)) ."', `order_place_date` = '" . $this->db->escape($orderDate) . "', `product_image_url` = '". $this->db->escape($productImageUrl) ."', `shipping_detail` = '" . $this->db->escape(json_encode($data['ShippingDetail'])) . "' ");
                $this->db->query("UPDATE `" . DB_PREFIX . "cedwish_order_error` SET store_order_id = '". $store_order_id ."' WHERE sku = '". $skuId ."' AND wish_order_id = '".$orderId."' ");
            }

            if($respo)
                $order_ids[] = $store_order_id;

        }else{
            $this->session->data['success'] = "Wish Order Can not Imported see Rejected List";
            // continue;
        }

        if (!empty($store_order_id)) {
            return $store_order_id;
        }
        return false;

    }

    public function getOpencartZoneByWishZoneCode($state_name)
    {
        $query=$this->db->query("SELECT `zone_id` FROM " . DB_PREFIX . "zone WHERE name='".$state_name."'");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }
    }

    public function getOpencartCountryByWishCountryCode($wish_country_code)
    {
        $query=$this->db->query("SELECT country_id, name FROM " . DB_PREFIX . "country WHERE iso_code_2 ='".$wish_country_code."'");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }
    }

    public function getOpencartLanguageByWishLanguageCode($wish_language_code)
    {
        $query=$this->db->query("SELECT language_id, name FROM " . DB_PREFIX . "language WHERE code ='".$wish_language_code."'");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }
    }

    public function getOpencartCurrencyByWishCurrencyCode($wish_currency_code)
    {
        $query=$this->db->query("SELECT currency_id FROM " . DB_PREFIX . "currency WHERE code ='".$wish_currency_code."'");
        if($query->num_rows)
        {
            return $query->row;
        } else {
            return array();
        }

    }

    public function getOrderStatusId($name)
    {
        return $this->config->get($name);
        // return $this->config->get('ced_wish_order_status');
    }
    public function getOpencartProductBySku($wish_product_id, $sku, $quantity, $wish_order_id, $product_title, $wish_price, $totalVat, $order_data)
    {
        $product=array();
        $sql = "SELECT `product_id`,`combination` FROM `" . DB_PREFIX . "cedwish_product_attribute_combination` WHERE `SkuId`='".$sku."'";
        $query = $this->db->query($sql);
        $result = $query->row;
        //echo '<pre>'; print_r($result); die;
        if($query->num_rows)
        {
            $combination=isset($result['combination'])?$result['combination']:'{}';
            $product_id=isset($result['product_id'])?$result['product_id']:'';
            $sql = "SELECT `status`,`minimum`,`quantity`,`model`,`price`FROM `".DB_PREFIX ."product` WHERE product_id = '".$product_id."'";
            $query = $this->db->query($sql);

            if($query->num_rows)
            {
                $status     =$query->row['status'];
                $minimum    =$query->row['minimum'];
                $qty_avail  =$query->row['quantity'];
                $model      =$query->row['model'];
                $price      =$query->row['price'];

                if($status || $this->config->get('ced_wish_status'))
                {
                    if($qty_avail >= $quantity)
                    {
                        $product['quantity']  = $quantity;
                        $product['product_id']= $product_id;
                        $product['model']     = $model;
                        $product['subtract']  = $quantity;
                        $product['price']     = ($wish_price) ? $wish_price : $price;
                        $product['total']     = ($wish_price) ? $quantity * $wish_price : $quantity * $price;
                        $product['tax']       = ($totalVat) ? $totalVat : '0';
                        $product['reward']    = 0;
                        $product['name']      = $product_title;
                        $product['option']    = json_decode($combination,true);
                        $product['download']  = array();
                        //echo '<pre>'; print_r($product); die;
                        return $product;
                    } else {
                        $this->addOrderErrorInfo($wish_order_id, $order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                        return '0';
                    }
                } else {
                    $this->addOrderErrorInfo($wish_order_id, $order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                    return '0';
                }
            } else {
                $this->addOrderErrorInfo($wish_order_id, $order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                return '0';
            }
        } else {
            $sql = "SELECT `product_id`, `status`, `minimum`, `quantity`, `model`, `price` FROM `" . DB_PREFIX . "product` WHERE `model` = ' ".$sku."' ";  // model => mapped as $sku
            $product_data = $this->db->query($sql);

            if($product_data && $product_data->num_rows && isset($product_data->row['product_id'])){
                $product_id = $product_data->row['product_id'];
                $status     = $product_data->row['status'];
                $minimum    = $product_data->row['minimum'];
                $qty_avail  = $product_data->row['quantity'];
                $model      = $product_data->row['model'];
                $price      = $product_data->row['price'];
                if($status || $this->config->get('ced_wish_status'))
                {
                    if($qty_avail >= $quantity)
                    {

                        $product['quantity']  = $quantity;
                        $product['product_id']= $product_id;
                        $product['model']     = $model;
                        $product['subtract']  = $quantity;
                        $product['price']     = ($wish_price) ? $wish_price : $price;
                        $product['total']     = ($wish_price) ? $quantity * $wish_price : $quantity * $price;
                        $product['tax']       = ($totalVat) ? $totalVat : '0';
                        $product['reward']    = 0;
                        $product['name']      = $product_title;
                        $product['option']    = array();
                        $product['download']  = array();

                        return $product;
                    } else {
                        $this->addOrderErrorInfo($wish_order_id, $order_data,"REQUESTED QUANTITY FOR PRODUCT ID ".$product_id." IS NOT AVAILABLE", $sku);
                        return '0';
                    }
                } else {
                    $this->addOrderErrorInfo($wish_order_id, $order_data,"PRODUCT STATUS IS DISABLED WITH ID ".$product_id, $sku);
                    return '0';
                }
            }else{
                $this->addOrderErrorInfo($wish_order_id, $order_data,"MERCHANT SKU DOES NOT EXIST", $sku);
                return '0';
            }
        }
    }
    public function addOrderErrorInfo($wish_order_id, $order_data, $error_message, $sku)
    {
        $already_exists = " SELECT * FROM `" . DB_PREFIX . "cedwish_order_error` WHERE `sku` = '" . $sku . "' ";
        $already_exists=$this->db->query($already_exists);
        if(!$already_exists->num_rows)
        {
            $sql = " INSERT INTO `" . DB_PREFIX . "cedwish_order_error` (`sku`, `wish_order_id`, `order_data`, `reason`)VALUES('" . $sku . "', '" . $wish_order_id . "', '". $this->db->escape(json_encode($order_data)) ."', '" . $error_message . "')";
            $result=$this->db->query($sql);
            if($result)
                return $wish_order_id;

        } else {
            $result = $this->db->query("UPDATE `" . DB_PREFIX . "cedwish_order_error` SET `wish_order_id` = '" . $wish_order_id . "', `order_data` = '". $this->db->escape(json_encode($order_data)) ."' , `reason` = '" . $error_message . "' WHERE sku = '". $sku ."' ");
            if($result)
                return $wish_order_id;

        }
    }
    public function checkOrderIdExists($order_id)
    {
        if($order_id) {
            $results = $this->db->query("SELECT `id` FROM `".DB_PREFIX."cedwish_order` where `order_id`='".$order_id."'");
            if ($results && $results->num_rows) {
                return true;
            }
            return false;
        } else {
            return false;
        }
    }

    public function addWishOrder($data)
    {

        $this->db->query("INSERT INTO `" . DB_PREFIX . "order` SET invoice_prefix = '" . $this->db->escape($data['invoice_prefix']) . "', store_id = '" . (int)$data['store_id'] . "', store_name = '" . $this->db->escape($data['store_name']) . "', store_url = '" . $this->db->escape($data['store_url']) . "', customer_id = '" . (int)$data['customer_id'] . "', customer_group_id = '" . (int)$data['customer_group_id'] . "', firstname = '" . $this->db->escape($data['firstname']) . "', lastname = '" . $this->db->escape($data['lastname']) . "', email = '" . $this->db->escape($data['email']) . "', telephone = '" . $this->db->escape($data['telephone']) . "', fax = '" . $this->db->escape($data['fax']) . "', custom_field = '" . $this->db->escape(isset($data['custom_field']) ? serialize($data['custom_field']) : '') . "', payment_firstname = '" . $this->db->escape($data['payment_firstname']) . "', payment_lastname = '" . $this->db->escape($data['payment_lastname']) . "', payment_company = '" . $this->db->escape($data['payment_company']) . "', payment_address_1 = '" . $this->db->escape($data['payment_address_1']) . "', payment_address_2 = '" . $this->db->escape($data['payment_address_2']) . "', payment_city = '" . $this->db->escape($data['payment_city']) . "', payment_postcode = '" . $this->db->escape($data['payment_postcode']) . "', payment_country = '" . $this->db->escape($data['payment_country']) . "', payment_country_id = '" . (int)$data['payment_country_id'] . "', payment_zone = '" . $this->db->escape($data['payment_zone']) . "', payment_zone_id = '" . (int)$data['payment_zone_id'] . "', payment_address_format = '" . $this->db->escape($data['payment_address_format']) . "', payment_custom_field = '" . $this->db->escape(isset($data['payment_custom_field']) ? serialize($data['payment_custom_field']) : '') . "', payment_method = '" . $this->db->escape($data['payment_method']) . "', payment_code = '" . $this->db->escape($data['payment_code']) . "', shipping_firstname = '" . $this->db->escape($data['shipping_firstname']) . "', shipping_lastname = '" . $this->db->escape($data['shipping_lastname']) . "', shipping_company = '" . $this->db->escape($data['shipping_company']) . "', shipping_address_1 = '" . $this->db->escape($data['shipping_address_1']) . "', shipping_address_2 = '" . $this->db->escape($data['shipping_address_2']) . "', shipping_city = '" . $this->db->escape($data['shipping_city']) . "', shipping_postcode = '" . $this->db->escape($data['shipping_postcode']) . "', shipping_country = '" . $this->db->escape($data['shipping_country']) . "', shipping_country_id = '" . (int)$data['shipping_country_id'] . "', shipping_zone = '" . $this->db->escape($data['shipping_zone']) . "', shipping_zone_id = '" . (int)$data['shipping_zone_id'] . "', shipping_address_format = '" . $this->db->escape($data['shipping_address_format']) . "', shipping_custom_field = '" . $this->db->escape(isset($data['shipping_custom_field']) ? serialize($data['shipping_custom_field']) : '') . "', shipping_method = '" . $this->db->escape($data['shipping_method']) . "', shipping_code = '" . $this->db->escape($data['shipping_code']) . "', comment = '" . $this->db->escape($data['comment']) . "', total = '" . (float)$data['total'] . "', affiliate_id = '" . (int)$data['affiliate_id'] . "', commission = '" . (float)$data['commission'] . "', marketing_id = '" . (int)$data['marketing_id'] . "', tracking = '" . $this->db->escape($data['tracking']) . "', language_id = '" . (int)$data['language_id'] . "', currency_id = '" . (int)$data['currency_id'] . "', currency_code = '" . $this->db->escape($data['currency_code']) . "', currency_value = '" . (float)$data['currency_value'] . "', ip = '" . $this->db->escape($data['ip']) . "', forwarded_ip = '" .  $this->db->escape($data['forwarded_ip']) . "', user_agent = '" . $this->db->escape($data['user_agent']) . "', accept_language = '" . $this->db->escape($data['accept_language']) . "', date_added = NOW(), date_modified = NOW() , order_status_id='".$this->getOrderStatusIdByName('complete')."'");

        $order_id = $this->db->getLastId();

        // Products
        foreach ($data['products'] as $product) {
            $this->db->query("INSERT INTO " . DB_PREFIX . "order_product SET order_id = '" . (int)$order_id . "', product_id = '" . (int)$product['product_id'] . "', name = '" . $this->db->escape($product['name']) . "', model = '" . $this->db->escape($product['model']) . "', quantity = '" . (int)$product['quantity'] . "', price = '" . (float)$product['price'] . "', total = '" . (float)$product['total'] . "', tax = '" . (float)$product['tax'] . "', reward = '" . (int)$product['reward'] . "'");

            $order_product_id = $this->db->getLastId();

            if(isset($product['option']) && count($product['option'])>0){
                foreach ($product['option'] as $option_id => $option_value) {
                    $sql="SELECT pov.product_option_value_id,po.product_option_id,od.name, ovd.name as `value`,o.type FROM ".DB_PREFIX."product_option_value pov LEFT JOIN ".DB_PREFIX."product_option po ON (po.product_id=pov.product_id AND po.option_id=pov.option_id) LEFT JOIN ".DB_PREFIX."option o ON (pov.option_id =o.option_id) LEFT JOIN ".DB_PREFIX."option_description od ON (pov.option_id =od.option_id) JOIN ".DB_PREFIX."option_value_description ovd ON (pov.option_id =ovd.option_id AND pov.option_value_id=ovd.option_value_id) where pov.option_value_id =". (int)$option_value." and pov.product_id=".(int)$product['product_id'];
                    $options_data=$this->db->query($sql);
                    if($options_data->num_rows){
                        $option=$options_data->row;
                        $this->db->query("INSERT INTO " . DB_PREFIX . "order_option SET order_id = '" . (int)$order_id . "', order_product_id = '" . (int)$order_product_id . "', product_option_id = '" . (int)$option['product_option_id'] . "', product_option_value_id = '" . (int)$option['product_option_value_id'] . "', name = '" . $this->db->escape($option['name']) . "', `value` = '" . $this->db->escape($option['value']) . "', `type` = '" . $this->db->escape($option['type']) . "'");
                    }
                }
            }
        }

        // Totals
        foreach ($data['totals'] as $total) {
            $this->db->query("INSERT INTO " . DB_PREFIX . "order_total SET order_id = '" . (int)$order_id . "', code = '" . $this->db->escape($total['code']) . "', title = '" . $this->db->escape($total['title']) . "', `value` = '" . (float)$total['value'] . "', sort_order = '" . (int)$total['sort_order'] . "'");
        }

        // $this->addOrderHistory($order_id, $this->config->get('ced_wish_order_status'));
        $this->addOrderHistory($order_id, $this->getOrderStatusId('CEDWISH_ORDER_STATE'));
        return $order_id;
    }

    public function addOrderHistory($order_id, $order_status_id, $comment = '', $notify = true)
    {
        $this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '" . (int)$order_status_id . "', notify = '" . (int)$notify . "', comment = '" . $this->db->escape($comment) . "', date_added = NOW()");
        $data=array();
        $data['order_status_id']=(int)$order_status_id;
        $data['order_id']=(int)$order_id;
        $data['comment']='A Wish Order Imported Successfully';
        $data['notify']=(int)$notify;

        $order_info = $this->getOrder($order_id);

        if ($order_info) {
            // Restock
            $product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

            foreach($product_query->rows as $product) {
                $this->db->query("UPDATE `" . DB_PREFIX . "product` SET quantity = (quantity - " . (int)$product['quantity'] . ") WHERE product_id = '" . (int)$product['product_id'] . "' AND subtract = '1'");

                $option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

                foreach ($option_query->rows as $option) {
                    $this->db->query("UPDATE " . DB_PREFIX . "product_option_value SET quantity = (quantity - " . (int)$product['quantity'] . ") WHERE product_option_value_id = '" . (int)$option['product_option_value_id'] . "' AND subtract = '1'");
                }
            }

            // If order status is 0 then becomes greater than 0 send main html email
            if ($order_status_id) {
                // Load the language for any mails that might be required to be sent out
                $language = new Language($order_info['language_code']);
                $language->load($order_info['language_code']);
                $language->load('mail/order');

                $order_status_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_status WHERE order_status_id = '" . (int)$order_status_id . "' AND language_id = '" . (int)$order_info['language_id'] . "'");

                if ($order_status_query->num_rows) {
                    $order_status = $order_status_query->row['name'];
                } else {
                    $order_status = '';
                }

                $subject = sprintf($language->get('text_new_subject'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'), $order_id);

                // HTML Mail
                $data = array();

                $data['title'] = sprintf($language->get('text_new_subject'), $order_info['store_name'], $order_id);

                $data['text_greeting'] = sprintf($language->get('text_new_greeting'), $order_info['store_name']);
                $data['text_link'] = $language->get('text_new_link');
                $data['text_download'] = $language->get('text_new_download');
                $data['text_order_detail'] = $language->get('text_new_order_detail');
                $data['text_instruction'] = $language->get('text_new_instruction');
                $data['text_order_id'] = $language->get('text_new_order_id');
                $data['text_date_added'] = $language->get('text_new_date_added');
                $data['text_payment_method'] = $language->get('text_new_payment_method');
                $data['text_shipping_method'] = $language->get('text_new_shipping_method');
                $data['text_email'] = $language->get('text_new_email');
                $data['text_telephone'] = $language->get('text_new_telephone');
                $data['text_ip'] = $language->get('text_new_ip');
                $data['text_order_status'] = $language->get('text_new_order_status');
                $data['text_payment_address'] = $language->get('text_new_payment_address');
                $data['text_shipping_address'] = $language->get('text_new_shipping_address');
                $data['text_product'] = $language->get('text_new_product');
                $data['text_model'] = $language->get('text_new_model');
                $data['text_quantity'] = $language->get('text_new_quantity');
                $data['text_price'] = $language->get('text_new_price');
                $data['text_total'] = $language->get('text_new_total');
                $data['text_footer'] = $language->get('text_new_footer');

                $data['logo'] = $this->config->get('config_url') . 'image/' . $this->config->get('config_logo');
                $data['store_name'] = $order_info['store_name'];
                $data['store_url'] = $order_info['store_url'];
                $data['customer_id'] = $order_info['customer_id'];
                $data['link'] = $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id;

                $data['order_id'] = $order_id;
                $data['date_added'] = date($language->get('date_format_short'), strtotime($order_info['date_added']));
                $data['payment_method'] = $order_info['payment_method'];
                $data['shipping_method'] = $order_info['shipping_method'];
                $data['email'] = $order_info['email'];
                $data['telephone'] = $order_info['telephone'];
                $data['ip'] = $order_info['ip'];
                $data['order_status'] = $order_status;

                if ($comment && $notify) {
                    $data['comment'] = nl2br($comment);
                } else {
                    $data['comment'] = '';
                }

                if ($order_info['payment_address_format']) {
                    $format = $order_info['payment_address_format'];
                } else {
                    $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
                }

                $find = array(
                    '{firstname}',
                    '{lastname}',
                    '{company}',
                    '{address_1}',
                    '{address_2}',
                    '{city}',
                    '{postcode}',
                    '{zone}',
                    '{zone_code}',
                    '{country}'
                );

                $replace = array(
                    'firstname' => $order_info['payment_firstname'],
                    'lastname'  => $order_info['payment_lastname'],
                    'company'   => $order_info['payment_company'],
                    'address_1' => $order_info['payment_address_1'],
                    'address_2' => $order_info['payment_address_2'],
                    'city'      => $order_info['payment_city'],
                    'postcode'  => $order_info['payment_postcode'],
                    'zone'      => $order_info['payment_zone'],
                    'zone_code' => $order_info['payment_zone_code'],
                    'country'   => $order_info['payment_country']
                );

                $data['payment_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

                if ($order_info['shipping_address_format']) {
                    $format = $order_info['shipping_address_format'];
                } else {
                    $format = '{firstname} {lastname}' . "\n" . '{company}' . "\n" . '{address_1}' . "\n" . '{address_2}' . "\n" . '{city} {postcode}' . "\n" . '{zone}' . "\n" . '{country}';
                }

                $find = array(
                    '{firstname}',
                    '{lastname}',
                    '{company}',
                    '{address_1}',
                    '{address_2}',
                    '{city}',
                    '{postcode}',
                    '{zone}',
                    '{zone_code}',
                    '{country}'
                );

                $replace = array(
                    'firstname' => $order_info['shipping_firstname'],
                    'lastname'  => $order_info['shipping_lastname'],
                    'company'   => $order_info['shipping_company'],
                    'address_1' => $order_info['shipping_address_1'],
                    'address_2' => $order_info['shipping_address_2'],
                    'city'      => $order_info['shipping_city'],
                    'postcode'  => $order_info['shipping_postcode'],
                    'zone'      => $order_info['shipping_zone'],
                    'zone_code' => $order_info['shipping_zone_code'],
                    'country'   => $order_info['shipping_country']
                );

                $data['shipping_address'] = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));


                // Products
                $data['products'] = array();
                $data['vouchers'] = array();

                foreach ($product_query->rows as $product) {
                    $option_data = array();

                    $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . (int)$product['order_product_id'] . "'");

                    foreach ($order_option_query->rows as $option) {
                        $value = $option['value'];

                        $option_data[] = array(
                            'name'  => $option['name'],
                            'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
                        );
                    }

                    $data['products'][] = array(
                        'name'     => $product['name'],
                        'model'    => $product['model'],
                        'option'   => $option_data,
                        'quantity' => $product['quantity'],
                        'price'    => $this->currency->format($product['price'] + ($this->config->get('config_tax') ? $product['tax'] : 0), $order_info['currency_code'], $order_info['currency_value']),
                        'total'    => $this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value'])
                    );
                }

                // Order Totals
                $data['totals'] = array();

                $order_total_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "order_total` WHERE order_id = '" . (int)$order_id . "' ORDER BY sort_order ASC");

                foreach ($order_total_query->rows as $total) {
                    $data['totals'][] = array(
                        'title' => $total['title'],
                        'text'  => $this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']),
                    );
                }

                // Text Mail
                $text  = sprintf($language->get('text_new_greeting'), html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8')) . "\n\n";
                $text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
                $text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
                $text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";

                if ($comment && $notify) {
                    $text .= $language->get('text_new_instruction') . "\n\n";
                    $text .= $comment . "\n\n";
                }

                // Products
                $text .= $language->get('text_new_products') . "\n";

                foreach ($product_query->rows as $product) {
                    $text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

                    $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

                    foreach ($order_option_query->rows as $option) {
                        $value = $option['value'];

                        $text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value) . "\n";
                    }
                }


                $text .= "\n";

                $text .= $language->get('text_new_order_total') . "\n";

                foreach ($order_total_query->rows as $total) {
                    $text .= $total['title'] . ': ' . html_entity_decode($this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";
                }

                $text .= "\n";

                if ($order_info['customer_id']) {
                    $text .= $language->get('text_new_link') . "\n";
                    $text .= $order_info['store_url'] . 'index.php?route=account/order/info&order_id=' . $order_id . "\n\n";
                }

                // Comment
                if ($order_info['comment']) {
                    $text .= $language->get('text_new_comment') . "\n\n";
                    $text .= $order_info['comment'] . "\n\n";
                }
                $text .= $language->get('text_new_footer') . "\n\n";

                $mail = new Mail();
                $mail->protocol = $this->config->get('config_mail_protocol');
                $mail->parameter = $this->config->get('config_mail_parameter');
                $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
                $mail->smtp_username = $this->config->get('config_mail_smtp_username');
                $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
                $mail->smtp_port = $this->config->get('config_mail_smtp_port');
                $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

                $mail->setTo($order_info['email']);
                $mail->setFrom($this->config->get('config_email'));
                $mail->setSender(html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
                $mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
                //$mail->setHtml($this->load->view('mail/order.tpl', $data));
                $mail->setText($text);
                $mail->send();

                // Admin Alert Mail
                if ($this->config->get('config_order_mail')) {
                    $subject = sprintf($language->get('text_new_subject'), html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8'), $order_id);

                    // HTML Mail
                    $data['text_greeting'] = $language->get('text_new_received');

                    if ($comment) {
                        if ($order_info['comment']) {
                            $data['comment'] = nl2br($comment) . '<br/><br/>' . $order_info['comment'];
                        } else {
                            $data['comment'] = nl2br($comment);
                        }
                    } else {
                        if ($order_info['comment']) {
                            $data['comment'] = $order_info['comment'];
                        } else {
                            $data['comment'] = '';
                        }
                    }

                    $data['text_download'] = '';

                    $data['text_footer'] = '';

                    $data['text_link'] = '';
                    $data['link'] = '';
                    $data['download'] = '';

                    // Text
                    $text  = $language->get('text_new_received') . "\n\n";
                    $text .= $language->get('text_new_order_id') . ' ' . $order_id . "\n";
                    $text .= $language->get('text_new_date_added') . ' ' . date($language->get('date_format_short'), strtotime($order_info['date_added'])) . "\n";
                    $text .= $language->get('text_new_order_status') . ' ' . $order_status . "\n\n";
                    $text .= $language->get('text_new_products') . "\n";

                    foreach ($order_product_query->rows as $product) {
                        $text .= $product['quantity'] . 'x ' . $product['name'] . ' (' . $product['model'] . ') ' . html_entity_decode($this->currency->format($product['total'] + ($this->config->get('config_tax') ? ($product['tax'] * $product['quantity']) : 0), $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";

                        $order_option_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_option WHERE order_id = '" . (int)$order_id . "' AND order_product_id = '" . $product['order_product_id'] . "'");

                        foreach ($order_option_query->rows as $option) {
                            if ($option['type'] != 'file') {
                                $value = $option['value'];
                            } else {
                                $value = utf8_substr($option['value'], 0, utf8_strrpos($option['value'], '.'));
                            }

                            $text .= chr(9) . '-' . $option['name'] . ' ' . (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value) . "\n";
                        }
                    }

                    foreach ($order_voucher_query->rows as $voucher) {
                        $text .= '1x ' . $voucher['description'] . ' ' . $this->currency->format($voucher['amount'], $order_info['currency_code'], $order_info['currency_value']);
                    }

                    $text .= "\n";

                    $text .= $language->get('text_new_order_total') . "\n";

                    foreach ($order_total_query->rows as $total) {
                        $text .= $total['title'] . ': ' . html_entity_decode($this->currency->format($total['value'], $order_info['currency_code'], $order_info['currency_value']), ENT_NOQUOTES, 'UTF-8') . "\n";
                    }

                    $text .= "\n";

                    if ($order_info['comment']) {
                        $text .= $language->get('text_new_comment') . "\n\n";
                        $text .= $order_info['comment'] . "\n\n";
                    }

                    $mail = new Mail();
                    $mail->protocol = $this->config->get('config_mail_protocol');
                    $mail->parameter = $this->config->get('config_mail_parameter');
                    $mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
                    $mail->smtp_username = $this->config->get('config_mail_smtp_username');
                    $mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
                    $mail->smtp_port = $this->config->get('config_mail_smtp_port');
                    $mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

                    $mail->setTo($this->config->get('config_email'));
                    $mail->setFrom($this->config->get('config_email'));
                    $mail->setSender(html_entity_decode($order_info['store_name'], ENT_QUOTES, 'UTF-8'));
                    $mail->setSubject(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
                    //$mail->setHtml($this->load->view('mail/order.tpl', $data));
                    $mail->setText($text);
                    $mail->send();

                    // Send to additional alert emails
                    $emails = explode(',', $this->config->get('config_mail_alert'));
                    foreach ($emails as $email) {
                        if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            $mail->setTo($email);
                            $mail->send();
                        }
                    }
                }
            }
        }
    }
    public function getOrderStatusIdByName($name)
    {
        $sql ="SELECT `order_status_id` FROM `".DB_PREFIX."order_status` WHERE `name`='".$name."'";
        $query=$this->db->query($sql);
        if($query && $query->num_rows)
            return $query->row['order_status_id'];
    }
    public function getOrder($order_id)
    {
        $order_query = $this->db->query("SELECT *, (SELECT CONCAT(c.firstname, ' ', c.lastname) FROM " . DB_PREFIX . "customer c WHERE c.customer_id = o.customer_id) AS customer FROM `" . DB_PREFIX . "order` o WHERE o.order_id = '" . (int)$order_id . "'");

        if ($order_query->num_rows) {
            $reward = 0;

            $order_product_query = $this->db->query("SELECT * FROM " . DB_PREFIX . "order_product WHERE order_id = '" . (int)$order_id . "'");

            foreach ($order_product_query->rows as $product) {
                $reward += $product['reward'];
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['payment_country_id'] . "'");

            if ($country_query->num_rows) {
                $payment_iso_code_2 = $country_query->row['iso_code_2'];
                $payment_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $payment_iso_code_2 = '';
                $payment_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['payment_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $payment_zone_code = $zone_query->row['code'];
            } else {
                $payment_zone_code = '';
            }

            $country_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "country` WHERE country_id = '" . (int)$order_query->row['shipping_country_id'] . "'");

            if ($country_query->num_rows) {
                $shipping_iso_code_2 = $country_query->row['iso_code_2'];
                $shipping_iso_code_3 = $country_query->row['iso_code_3'];
            } else {
                $shipping_iso_code_2 = '';
                $shipping_iso_code_3 = '';
            }

            $zone_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "zone` WHERE zone_id = '" . (int)$order_query->row['shipping_zone_id'] . "'");

            if ($zone_query->num_rows) {
                $shipping_zone_code = $zone_query->row['code'];
            } else {
                $shipping_zone_code = '';
            }

            if ($order_query->row['affiliate_id']) {
                $affiliate_id = $order_query->row['affiliate_id'];
            } else {
                $affiliate_id = 0;
            }

            $affiliate_firstname = '';
            $affiliate_lastname = '';

            $language_code = '';
            $language_filename = '';
            $language_directory = '';

            return array(
                'order_id'                => $order_query->row['order_id'],
                'invoice_no'              => $order_query->row['invoice_no'],
                'invoice_prefix'          => $order_query->row['invoice_prefix'],
                'store_id'                => $order_query->row['store_id'],
                'store_name'              => $order_query->row['store_name'],
                'store_url'               => $order_query->row['store_url'],
                'customer_id'             => $order_query->row['customer_id'],
                'customer'                => $order_query->row['customer'],
                'customer_group_id'       => $order_query->row['customer_group_id'],
                'firstname'               => $order_query->row['firstname'],
                'lastname'                => $order_query->row['lastname'],
                'email'                   => $order_query->row['email'],
                'telephone'               => $order_query->row['telephone'],
                'fax'                     => $order_query->row['fax'],
                'custom_field'            => unserialize($order_query->row['custom_field']),
                'payment_firstname'       => $order_query->row['payment_firstname'],
                'payment_lastname'        => $order_query->row['payment_lastname'],
                'payment_company'         => $order_query->row['payment_company'],
                'payment_address_1'       => $order_query->row['payment_address_1'],
                'payment_address_2'       => $order_query->row['payment_address_2'],
                'payment_postcode'        => $order_query->row['payment_postcode'],
                'payment_city'            => $order_query->row['payment_city'],
                'payment_zone_id'         => $order_query->row['payment_zone_id'],
                'payment_zone'            => $order_query->row['payment_zone'],
                'payment_zone_code'       => $payment_zone_code,
                'payment_country_id'      => $order_query->row['payment_country_id'],
                'payment_country'         => $order_query->row['payment_country'],
                'payment_iso_code_2'      => $payment_iso_code_2,
                'payment_iso_code_3'      => $payment_iso_code_3,
                'payment_address_format'  => $order_query->row['payment_address_format'],
                'payment_custom_field'    => unserialize($order_query->row['payment_custom_field']),
                'payment_method'          => $order_query->row['payment_method'],
                'payment_code'            => $order_query->row['payment_code'],
                'shipping_firstname'      => $order_query->row['shipping_firstname'],
                'shipping_lastname'       => $order_query->row['shipping_lastname'],
                'shipping_company'        => $order_query->row['shipping_company'],
                'shipping_address_1'      => $order_query->row['shipping_address_1'],
                'shipping_address_2'      => $order_query->row['shipping_address_2'],
                'shipping_postcode'       => $order_query->row['shipping_postcode'],
                'shipping_city'           => $order_query->row['shipping_city'],
                'shipping_zone_id'        => $order_query->row['shipping_zone_id'],
                'shipping_zone'           => $order_query->row['shipping_zone'],
                'shipping_zone_code'      => $shipping_zone_code,
                'shipping_country_id'     => $order_query->row['shipping_country_id'],
                'shipping_country'        => $order_query->row['shipping_country'],
                'shipping_iso_code_2'     => $shipping_iso_code_2,
                'shipping_iso_code_3'     => $shipping_iso_code_3,
                'shipping_address_format' => $order_query->row['shipping_address_format'],
                'shipping_custom_field'   => unserialize($order_query->row['shipping_custom_field']),
                'shipping_method'         => $order_query->row['shipping_method'],
                'shipping_code'           => $order_query->row['shipping_code'],
                'comment'                 => $order_query->row['comment'],
                'total'                   => $order_query->row['total'],
                'reward'                  => $reward,
                'order_status_id'         => $order_query->row['order_status_id'],
                'affiliate_id'            => $order_query->row['affiliate_id'],
                'affiliate_firstname'     => $affiliate_firstname,
                'affiliate_lastname'      => $affiliate_lastname,
                'commission'              => $order_query->row['commission'],
                'language_id'             => $order_query->row['language_id'],
                'language_code'           => $language_code,
                'language_filename'       => $language_filename,
                'language_directory'      => $language_directory,
                'currency_id'             => $order_query->row['currency_id'],
                'currency_code'           => $order_query->row['currency_code'],
                'currency_value'          => $order_query->row['currency_value'],
                'ip'                      => $order_query->row['ip'],
                'forwarded_ip'            => $order_query->row['forwarded_ip'],
                'user_agent'              => $order_query->row['user_agent'],
                'accept_language'         => $order_query->row['accept_language'],
                'date_added'              => $order_query->row['date_added'],
                'date_modified'           => $order_query->row['date_modified']
            );
        } else {
            return;
        }
    }


    public function log($data, $force_log =true ) {
        if ($this->config->get('ced_wish_enable_logging') || $force_log) {
            $backtrace = debug_backtrace();
            $log = new Log('ced_wish.log');
            $log->write('(' . $backtrace[1]['class'] . '::' . $backtrace[1]['function'] . ') - ' . print_r($data, true));
        }
    }

    public function cancelOrder($wish_order_id, $cancelationReason, $reasonNote)
    {
        $response = array();
        $path = 'order/refund';

        if($cancelationReason == '-1')
            $reasonNote = $reasonNote;
        else
            $reasonNote = '';

        $params = array(
            'id' => $wish_order_id,
            'reason_code' => $cancelationReason,
            'reason_note' => $reasonNote,
            'access_token' => $this->accessToken
        );

        $tokenResponse = $this->postRequest($path, $params);
        $request = $tokenResponse['response'];
        //echo '<pre>'; print_r($tokenResponse); die;
        if(isset($request['code']) && $request['code'] == 0)
        {
            $this->db->query("UPDATE `". DB_PREFIX ."cedwish_order` SET wish_status = 'CANCELLED' WHERE wish_order_id = '". $wish_order_id ."' ");
            $response = array('success' => true, 'message' => 'Order Cancelled Successfully');
        } else {
            $this->db->query("UPDATE `". DB_PREFIX ."cedwish_order` SET message = '". json_encode($request['message']) ."' WHERE wish_order_id = '". $wish_order_id ."' ");
            $errorMsgUpdate = $this->addErrorMessage($wish_order_id, $request['message']);
            $response = array('success' => false, 'message' => $request['message']);
        }
        return $response;
    }


    public function shipCompleteOrder($wish_order_id, $trackingProvider, $trackingNumber, $shipNote='')
    {

        $response = array();
        $path = 'order/modify-tracking';

        if($shipNote)
            $shipNote = $shipNote;
        else
            $shipNote = '';

        $params = array(
            'id' => $wish_order_id,
            'tracking_provider' => $trackingProvider,
            'tracking_number' => $trackingNumber,
            'ship_note' => $shipNote,
            'access_token' => $this->accessToken
        );
        $tokenResponse = $this->postRequest($path, $params);
        $request = $tokenResponse['response'];
        if(isset($request['code']) && $request['code'] == 0)
        {
            $this->db->query("UPDATE `". DB_PREFIX ."cedwish_order` SET wish_status = 'SHIPPED' WHERE wish_order_id = '". $wish_order_id ."' ");
            $response = array('success' => true, 'message' => 'Order Shipped Successfully');
        } else {
            $message = explode(':', $request['message']);
            @$order_status = $message[1];

            $this->db->query("UPDATE `". DB_PREFIX ."cedwish_order` SET wish_status = '". $this->db->escape($order_status) ."' WHERE wish_order_id = '". $wish_order_id ."' ");

            $errorMsgUpdate = $this->addErrorMessage($wish_order_id, $request['message']);

            $response = array('success' => false, 'message' => $request['message']);
        }
        return $response;
    }

    public function addErrorMessage($wish_order_id, $error_message){

        $query = $this->db->query("SELECT count(sku) AS count_sku FROM `". DB_PREFIX ."cedwish_order_error` WHERE wish_order_id = '". $wish_order_id ."' ");
        $result = $query->row;

        if($result['count_sku'] > '0'){
            $this->db->query("UPDATE `". DB_PREFIX ."cedwish_order_error` SET reason ='". $this->db->escape($error_message) ."' WHERE wish_order_id = '". $wish_order_id ."' ");
        } else {
            $sql = $this->db->query("SELECT store_order_id, sku FROM `". DB_PREFIX ."cedwish_order` WHERE wish_order_id = '". $wish_order_id ."' ");
            $res = $sql->row;

            $this->db->query("INSERT INTO `". DB_PREFIX ."cedwish_order_error` (`store_order_id`, `sku`, `wish_order_id`, `reason`) VALUES ('". (int)$res['store_order_id'] ."', '". $this->db->escape($res['sku']) ."', '". $this->db->escape($wish_order_id) ."', '". $this->db->escape($error_message) ."') ");
        }
        return;
    }

    public function validateProduct($data)
    {
        $result = array();
        $validation = $this->getValidationArray();
        $result['error'] = '';
        foreach ($validation as $key => $value) {
            $key = trim($key);
            if(isset($value['is_required']) && $value['is_required'] && isset($data[$key])) {
                switch ($key) {
                    case 'product_id':
                        if (isset($data['product_id']) && $data['product_id']) {
                            if (strlen(trim($data['product_id'])) > $value['length']) {
                                $result['error'] .= 'The length of Product id must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'sku':
                        if (isset($data['sku']) && $data['sku']) {
                            if (strlen(trim($data['sku'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'name':
                        if (isset($data['name']) && $data['name']) {
                            if (strlen(trim($data['name'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;

                    case 'main_image':
                        if (isset($data['main_image']) && $data['main_image']) {
                            if (strlen(trim($data['main_image'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'description':
                        if (isset($data['description']) && $data['description']) {
                            if (strlen(trim($data['description'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'shipping':
                        if (isset($data['shipping'])) {
                            if (strlen(trim($data['shipping'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'tags':
                        if (isset($data['tags'])) {
                            if (strlen(trim($data['tags'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'inventory':
                        if (isset($data['inventory'])) {
                            if (strlen(trim($data['inventory'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                    case 'price':
                        if (isset($data['price'])) {
                            if ((float)(trim($data['price']))) {
                                $data['price'] = number_format(trim($data['price']),2,'.', '');
                                if (strlen($data['price']) > $value['length']) {
                                    $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                }
                            } else {
                                $result['error'] .= $key.' should be numeric. </br>';
                            }
                        } else {
                            $result['error'] .= $key.' is a required field. </br>';
                        }
                        break;
                }
            } else if(isset($value['is_required']) && !$value['is_required']) {
                if(isset($data[$key]) && !$data[$key])
                    continue;
                switch ($key) {
                    case 'parent_sku':
                        if (isset($data['parent_sku']) && $data['parent_sku']) {
                            if (strlen(trim($data['parent_sku'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'upc':
                        if (isset($data['upc'])) {
                            if (is_numeric((trim($data['upc'])))) {
                                $data['upc'] = (float)trim($data['upc']);
                                if (strlen($data['upc']) > $value['length']) {
                                    $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                                }
                            } else {
                                $result['error'] .= $key.' should be numeric. </br>';
                            }
                        }
                        break;
                    case 'landing_page_url':
                        if (isset($data['landing_page_url']) && ($data['landing_page_url'])) {
                            if (strlen(trim($data['landing_page_url'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    // case 'stock_status':
                    //     if (isset($data['StockStatus'])) {
                    //         if (strlen(trim($data['StockStatus'])) > $value['length']) {
                    //             $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                    //         }
                    //     }
                    //     break;
                    case 'pieces':
                        if (isset($data['pieces']) && is_numeric(($data['pieces']))) {
                            if (strlen(trim($data['pieces'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'extra_images':
                        if (isset($data['extra_images'])) {
                            if (strlen(trim($data['extra_images'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'size':
                        if (isset($data['size'])) {
                            if (strlen(trim($data['size'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'color':
                        if (isset($data['color'])) {
                            if (strlen(trim($data['color'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'declared_local_name':
                        if (isset($data['declared_local_name']) && $data['declared_local_name']) {
                            if (strlen(trim($data['declared_local_name'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'manufacturer':
                        if (isset($data['manufacturer'])) {
                            if (strlen(trim($data['manufacturer'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'hscode':
                        if (isset($data['hscode'])) {
                            if (strlen(trim($data['hscode'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'has_powder':
                        if (isset($data['has_powder'])) {
                            if (strlen(trim($data['has_powder'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'has_liquid':
                        if (isset($data['has_liquid'])) {
                            if (strlen(trim($data['has_liquid'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'has_battery':
                        if (isset($data['has_battery'])) {
                            if (strlen(trim($data['has_battery'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'has_metal':
                        if (isset($data['has_metal'])) {
                            if (strlen(trim($data['has_metal'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'declared_value':
                        if (isset($data['declared_value']) && is_numeric($data['declared_value'])) {
                            if (strlen(trim($data['declared_value'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'length':
                        if (isset($data['length']) && is_numeric($data['length'])) {
                            if (strlen(trim($data['length'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'width':
                        if (isset($data['width']) && is_numeric($data['width'])) {
                            if (strlen(trim($data['width'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'height':
                        if (isset($data['height']) && is_numeric($data['height'])) {
                            if (strlen(trim($data['height'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'weight':
                        if (isset($data['weight']) && is_numeric($data['weight'])) {
                            if (strlen(trim($data['weight'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'max_quantity':
                        if (isset($data['max_quantity']) && is_numeric($data['max_quantity'])) {
                            if (strlen(trim($data['max_quantity'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'shipping_time':
                        if (isset($data['shipping_time'])) {
                            if (strlen(trim($data['shipping_time'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'origin_country':
                        if (isset($data['origin_country'])) {
                            if (strlen(trim($data['origin_country'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'msrp':
                        if (isset($data['msrp'])) {
                            if (strlen(trim($data['msrp'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'brand':
                        if (isset($data['brand']) && $data['brand']) {
                            if (strlen(trim($data['brand'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                    case 'declared_name':
                        if (isset($data['declared_name']) && $data['declared_name']) {
                            if (strlen(trim($data['declared_name'])) > $value['length']) {
                                $result['error'] .= 'The length of '.$key.' must not exceed '.$value['length'].'</br>';
                            }
                        }
                        break;
                }
            } else {
                $result['error'] .= $key.' is Required Field.'.'</br>';
            }
        }
        return $result;
    }

    public function getValidationArray(){

        return array(
            'product_id' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50,
                'description' => 'Your own product identifier code that you recognise when it is provided on order information.The same ProductId should be used to group together Skus where they are available with multiple options (Colours, Sizes etc.).'
            ),
            'name' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 150,
                'description' => '  Name of the product as shown to users on Wish.'
            ),
            'description' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 5000,
                'description' => 'Description of the product. Should not contain HTML. If you want a new line use "\n".'
            ),
            'declared_name' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 150,
                'description' => 'Product name for logistics declaration.'
            ),
            'declared_local_name' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 150,
                'description' => 'Product name written in local language for logistics declaration.'
            ),
            'pieces' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 5,
                'description' => 'The amount of pieces associated with this item.'
            ),
            'tags' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 100,
                'description' => 'Comma separated list of strings that describe the product. Only 10 are allowed. Any tags past 10 will be ignored.'
            ),
            'sku' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 50,
                'description' => 'The unique identifier that your system uses to recognize this product.'
            ),
            'size' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => ' The size of the product. Example: Large, Medium, Small, 5, 6, 7.5.'
            ),
            'color' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 30,
                'description' => 'The color of the product. Example: red, blue, green.'
            ),
            'inventory' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 7,
                'description' => 'The physical quantities you have for this product, max 500,000'
            ),
            'price' => array(
                'type' => 'digits',
                'is_required' => true ,
                'length' => 7,
                'description' => "The price of the variation when the user purchases one, max 100,000."
            ),
            'shipping' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 10,
                'description' => "The shipping of the product when the user purchases one, max 1000."
            ),
            'msrp' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 7,
                'description' => "Manufacturer's Suggested Retail Price. This field is recommended as it will show as a strikethrough price on Wish and appears above the selling price for the product."
            ),
            'shipping_time' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 10,
                'description' => "The amount of time it takes for the shipment to reach the buyer. Please also factor in the time it will take to fulfill and ship the item. Provide a time range in number of days. Lower bound cannot be less than 2 days. Upper bound must be at least 5 days after the lower bound. Example: 15-20."
            ),
            'main_image' => array(
                'type' => 'string',
                'is_required' => true ,
                'length' => 2150,
                'description' => 'URL of a photo of your product. Link directly to the image, not the page where it is located. We accept JPEG, PNG or GIF format. Images should be at least 100 x 100 pixels in size.'
            ),
            'parent_sku' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 50,
                'description' => 'When defining a variant of a product we must know which product to attach the variation to. parent_sku is the unique id of the product that you can use later when using the add product variation API..'
            ),
            'brand' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 100,
                'description' => 'Brand or manufacturer of your product.'
            ),
            'landing_page_url' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 50,
                'description' => 'URL on your website containing the product details.'
            ),
            'upc' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 12,
                'description' => '12-digit Universal Product Codes (UPC)-contains no letters or other characters.'
            ),
            'extra_images' => array(
                'type' => 'string',
                'is_required' => false ,
                'length' => 2150,
                'description' => "URL of extra photos of your product. Link directly to the image, not the page where it is located. Same rules apply as Imageurl1. You can specify one or more additional images separated by the character '|'. The total number of extra images plus the number of variation images must not exceed 20."
            ),
            'max_quantity' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 5,
                'description' => "The maximum quantity of products per order."
            ),
            'length' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 10,
                'description' => "The length of your product that will be packaged to ship to customer (Units in cm)."
            ),
            'width' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 10,
                'description' => "The width of your product that will be packaged to ship to customer (Units in cm)."
            ),
            'height' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 10,
                'description' => "The height of your product that will be packaged to ship to customer (Units in cm)."
            ),
            'weight' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 10,
                'description' => "The weight of your product that will be packaged to ship to customer (Units in cm)."
            ),
            'declared_value' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 7,
                'description' => "The price of your product that will be declared to custom."
            ),
            'hscode' => array(
                'type' => 'digits',
                'is_required' => false ,
                'length' => 30,
                'description' => "Harmonization System Code used for custom declaration."
            ),
            'origin_country' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 150,
                'case' => 'upper',
                'values' => $this->getCountry(),
                'description' => 'Country where product is manufactured. Country code should follow ISO 3166 Alpha-2 code. Example:CN, US.'
            ),
            'has_powder' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 10,
                'description' => 'Whether product contains powder. Example: true, false.'
            ),
            'has_liquid' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 10,
                'description' => 'Whether product contains liquid. Example: true, false.'
            ),
            'has_battery' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 10,
                'description' => 'Whether product contains battery. Example: true, false.'
            ),
            'has_metal' => array(
                'type' => 'select',
                'is_required' => false ,
                'length' => 10,
                'description' => 'Whether product contains metal. Example: true, false.'
            )
        );
    }

    function getCountry() {
        $query = $this->db->query("SELECT country_id, name FROM " . DB_PREFIX . "country GROUP BY name ORDER BY name");
        return $query->rows;
    }

    function validDate($date, $format = 'Y-m-d')
    {
        $date_obj = DateTime::createFromFormat($format, $date);
        return $date_obj && $date_obj->format($format) == $date;
    }

    public function updateStock($product_ids=array(), $keyFor)
    {
        if(is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0) {
            $product_ids = $this->getAllMappedProducts();

            if(empty($product_ids))
                $product_ids = $this->getAllWishProducts();

            $product_ids = array_unique($product_ids);
        }
        try{

            if(count($product_ids)){
                $productids_chunk = array_chunk($product_ids,'999');
                $inventory_chunk = array();

                $sql = $this->db->query("SELECT `inventory_chunk` FROM `" . DB_PREFIX . "cedwish_products_cron` WHERE `type` = 'updatestock'");
                $result = $sql->rows;
                if (count($result) && isset($result[0]['inventory_chunk']) && count($result[0]['inventory_chunk'])) {
                    $inventory_chunk = json_decode($result[0]['inventory_chunk'], true);
                }
                $finalInventoryChunk = array();
                if (!count($inventory_chunk)) {
                    $this->db->query("INSERT INTO `". DB_PREFIX ."cedwish_products_cron` (`inventory_chunk`, `type`) VALUES ('". $this->db->escape(json_encode($productids_chunk)) ."', 'updatestock') ");

                    $inventory_chunk = $productids_chunk;
                } else {
                    foreach ($inventory_chunk as $chunk) {
                        if (is_array($chunk)) {
                            foreach ($chunk as $id) {
                                $finalInventoryChunk[] = $id;
                            }
                        }
                    }
                    foreach ($productids_chunk as $chunk) {
                        if (is_array($chunk)) {
                            foreach ($chunk as $id) {
                                $finalInventoryChunk[] = $id;
                            }
                        }
                    }
                    $inventory_chunk = array_unique($finalInventoryChunk);
                    $inventory_chunk = array_chunk($inventory_chunk, 999);
                }
                $response = array();
                foreach ($inventory_chunk as $chk => $product_ids) {

                    $updatestock = array();
                    $prod_ids = array_chunk($product_ids,'100');

                    $feed_array = array();
                    foreach ($prod_ids as $key => $prod_id)
                    {
                        foreach ($prod_id as $product_id)
                        {
                            $query = $this->db->query("SELECT profile_id FROM `".DB_PREFIX."cedwish_product_variations` WHERE product_id = '". $product_id ."' ");
                            $result = $query->row;

                            $product_combination = $this->productOptionCombination($product_id, $result['profile_id']);

                            if(!empty($product_combination))
                            {
                                foreach($product_combination as $single_combi)
                                {
                                    $SkuId = $single_combi['sku'];
                                    $option_attribute = $this->getOptionAttribute($product_id, $SkuId, $single_combi);

                                    if(isset($SkuId) && isset($option_attribute['quantity']))
                                    {
                                        $sku = $SkuId;
                                        $quantity = $option_attribute['quantity'];

                                        $updatestock[] = array(
                                            'sku' => $sku,
                                            'inventory' => $quantity
                                        );
                                    }
                                }

                            } else {

                                $query = $this->db->query("SELECT quantity FROM " . DB_PREFIX . "product WHERE `product_id` ='".$product_id."'");
                                $result = $query->rows;

                                $sku_query = $this->db->query("SELECT sku FROm `". DB_PREFIX ."cedwish_product_variations` WHERE product_id = '". $product_id ."' ");
                                $sku_result = $sku_query->rows;

                                $quantity = 0;
                                if(isset($result['0']['quantity']))
                                    $quantity = $result['0']['quantity'];
                                if(isset($sku_result['0']['sku']))
                                    $sku = $sku_result['0']['sku'];

                                $updatestock[] = array(
                                    'sku' => $sku,
                                    'inventory' => $quantity
                                );
                            }
                        }
                    }

                    if($updatestock){

                        $params = json_encode($updatestock);
                        $path = 'variant/bulk-sku-update';
                        $final_array = array(
                            'updates' => $params,
                            'access_token' => $this->accessToken
                        );

                        $tokenResponse = $this->postRequest($path, $final_array);
                        $request = $tokenResponse['response'];

                        if(isset($request['code']) && $request['code'] == 0) {
                            $data = $request['data'];
                            $job_id = $data['job_id']; // 5b3b7a9552e28532730842cd

                            $this->db->query("DELETE FROM `". DB_PREFIX ."cedwish_products_cron` WHERE `type` = 'updatestock' ");

                            unset($inventory_chunk[$chk]);
                            $inventory_chunk = array_values($inventory_chunk);

                            $this->db->query("INSERT INTO `". DB_PREFIX ."cedwish_products_cron` (`inventory_chunk`, `type`) VALUES ('". $this->db->escape(json_encode($inventory_chunk)) ."', 'updatestock') ");

                            foreach ($updatestock as $stock) {
                                $this->db->query("UPDATE `". DB_PREFIX ."cedwish_variant_response` SET `inventory` = '". (int)$stock['inventory'] ."' WHERE sku = '".$stock['sku']."' ");

                                $parent_sku_query = $this->db->query("SELECT parent_sku FROM `". DB_PREFIX ."cedwish_variant_response` WHERE sku = '".$stock['sku']."' ");
                                $parent_sku_result = $parent_sku_query->row;

                                if(isset($parent_sku_result) && !empty($parent_sku))
                                {
                                    $parent_sku = $parent_sku_result['parent_sku'];

                                    $this->db->query("UPDATE `". DB_PREFIX ."cedwish_product_response` SET job_id = '". $this->db->escape($job_id) ."' WHERE sku = '". $this->db->escape($parent_sku) ."' ");

                                    $sql = $this->db->query("SELECT count(parent_sku) AS count_parent_sku FROM `". DB_PREFIX."cedwish_job_status` WHERE parent_sku = '". $this->db->escape($parent_sku) ."' ");
                                    $res = $sql->row;

                                    if($res['count_parent_sku'] > '0')
                                        $this->db->query("UPDATE `". DB_PREFIX."cedwish_job_status` SET job_id = '". $this->db->escape($job_id) ."' WHERE parent_sku = '". $this->db->escape($parent_sku) ."' ");
                                    else
                                        $this->db->query("INSERT INTO `". DB_PREFIX."cedwish_job_status` (`parent_sku`, `job_id`) VALUES ('". $this->db->escape($parent_sku) ."', '". $this->db->escape($job_id) ."') ");
                                } else {

                                    $this->db->query("UPDATE `". DB_PREFIX ."cedwish_product_response` SET job_id = '". $this->db->escape($job_id) ."' WHERE sku = '". $this->db->escape($stock['sku']) ."' ");

                                    $sql = $this->db->query("SELECT count(parent_sku) AS count_parent_sku FROM `". DB_PREFIX."cedwish_job_status` WHERE parent_sku = '". $this->db->escape($stock['sku']) ."' ");
                                    $res = $sql->row;

                                    if($res['count_parent_sku'] > '0')
                                        $this->db->query("UPDATE `". DB_PREFIX."cedwish_job_status` SET job_id = '". $this->db->escape($job_id) ."' WHERE parent_sku = '". $this->db->escape($stock['sku']) ."' ");
                                    else
                                        $this->db->query("INSERT INTO `". DB_PREFIX."cedwish_job_status` (`parent_sku`, `job_id`) VALUES ('". $this->db->escape($stock['sku']) ."', '". $this->db->escape($job_id) ."') ");

                                }

                            }
                            $response = array('success' => true, 'message' => 'Product Synced Successfully!');
                        } else{
                            $response = array('success'=> false, 'message' => $request['message']);
                        }
                    }
                }

                return $response;
            }
        } catch(Exception $e){
            $this->log($e->getMessage());
        }
    }

    public function getOptionAttribute($product_id, $sku, $combi_array = array())
    {
        $option_attributes = array();
        $query = $this->db->query("SELECT combination FROM `". DB_PREFIX ."cedwish_product_attribute_combination` WHERE product_id = '". $product_id ."' AND SkuId = '". $sku ."' ");
        $result = $query->rows;
        $combination = array();
        if(isset($result) && !empty($result))
        {
            foreach($result as $key)
            {
                $combination = json_decode($key['combination'], true);
                $quantity_array = array();
                //$quantity = '0';
                foreach($combination as $option_id => $name)
                {
                    if($option_id != 'sku')
                    {
                        $option_value_query = $this->db->query("SELECT pov.quantity FROM `". DB_PREFIX ."option_value_description` AS ovd JOIN `". DB_PREFIX ."product_option_value` AS pov ON (ovd.option_value_id = pov.option_value_id) WHERE ovd.option_id = '". $option_id ."' AND ovd.name = '". $name ."' AND pov.product_id = '". $product_id ."' ");
                        $option_value_res = $option_value_query->row;

                        if(isset($option_value_res['quantity']) && $option_value_res['quantity'])
                            $quantity_array[] = $option_value_res['quantity'];
//                        if(!empty($option_value_res['quantity']))
//                            $quantity = $option_value_res['quantity'];
//                        else
//                            $quantity = '0';
                    }
                }
                $option_attributes = array('quantity' => min($quantity_array));
                //echo '<pre>'; print_r($option_attributes); die;
                return $option_attributes;
            }
        } else {
            if(!isset($combi_array['0'])){
                $temp_combi_array = $combi_array;
                $combi_array = array();
                $combi_array['0'] = $temp_combi_array;
            }
            foreach($combi_array as $key)
            {
                //$quantity = '0';
                $quantity_array = array();
                foreach($key as $option_id => $name)
                {
                    if($option_id != 'sku'){
                        $option_value_query = $this->db->query("SELECT pov.quantity FROM `". DB_PREFIX ."option_value_description` AS ovd JOIN `". DB_PREFIX ."product_option_value` AS pov ON (ovd.option_value_id = pov.option_value_id) WHERE ovd.option_id = '". $option_id ."' AND ovd.name = '". $name ."' AND pov.product_id = '". $product_id ."' ");
                        $option_value_res = $option_value_query->row;
                        if(isset($option_value_res['quantity']) && $option_value_res['quantity'])
                            $quantity_array[] = $option_value_res['quantity'];
//                        if(!empty($option_value_res['quantity']))
//                            $quantity+=$option_value_res['quantity'];
//                        else
//                            $quantity = '0';
                    }
                }
                $option_attributes = array('quantity' => min($quantity_array));
                return $option_attributes;
            }
        }
    }

    public function fetchStock($product_ids=array())
    {
        if(is_numeric($product_ids)) {
            $product_ids = array($product_ids);
        }
        if(count($product_ids)==0)
        {
            $product_ids = $this->getAllMappedProducts();

            if(empty($product_ids))
                $product_ids = $this->getAllWishProducts();

            $product_ids = array_unique($product_ids);
        }
        if(count($product_ids))
        {
            $response = array();
            foreach($product_ids as $key => $product_id){
                $product_id = (int)$product_id;
                try
                {
                    $query = $this->db->query("SELECT sku FROM `". DB_PREFIX ."cedwish_product_response` WHERE product_id = '". $product_id ."' ");
                    $result = $query->row;

                    $query1 = $this->db->query("SELECT cjs.job_id FROM `". DB_PREFIX ."cedwish_product_response` AS cpr JOIN `". DB_PREFIX ."cedwish_job_status` AS cjs ON (cpr.sku = cjs.parent_sku) WHERE cpr.product_id = '". $product_id ."'  ");
                    $result1 = $query1->row;

                    $path = 'product';
                    $params = array(
                        'parent_sku' => $result['sku'],
                        'access_token' => $this->accessToken
                    );

                    $tokenResponse = $this->postRequest($path, $params);
                    $request = $tokenResponse['response'];
//echo '<pre>'; print_r($tokenResponse); die;
                    if(isset($request['code']) && $request['code'] == 0) {
                        $data = $request['data'];
                        $wishProductId = $data['Product']['id'];
                        $reviewStatus = $data['Product']['review_status'];

                        $this->db->query("UPDATE `". DB_PREFIX ."cedwish_product_response` SET review_status = '". $reviewStatus ."' WHERE wish_product_id = '". $wishProductId ."' ");

                        $bulkUpdateJobStatus = $this->getBulkUpdateJobStatus($product_id);

                        if(is_array($bulkUpdateJobStatus))
                            $response = array('success' => true, 'message'=> $bulkUpdateJobStatus['message']);
                        else
                            $response = array('success' => true, 'message'=> 'Product(s) Status Fetched Successfully!');

                    } else {
                        $response = array('success' => false, 'message'=> $request['message']);
                    }

                } catch (Exception $e) {
                    return array('success' => false, 'message' => 'No Response From Wish');
                }
            }
            //echo '<pre>'; print_r($response); die;
            return $response;
        }

    }

    public function getBulkUpdateJobStatus($product_id)
    {
        $response = array();


        $query = $this->db->query("SELECT cjs.job_id FROM `". DB_PREFIX ."cedwish_product_response` AS cpr JOIN `". DB_PREFIX ."cedwish_job_status` AS cjs ON (cpr.sku = cjs.parent_sku) WHERE cpr.product_id = '". $product_id ."'  ");
        $result = $query->row;
        if(isset($result) && !empty($result['job_id'])){
            $path = 'variant/get-bulk-update-job-status';
            $params = array(
                'job_id' => $result['job_id'],
                'access_token' => $this->accessToken
            );

            $tokenResponse = $this->getRequest($path, $params);
            $request = $tokenResponse['response'];

            if(isset($request['code']) && $request['code'] == 0) {
                $data = $request['data'];
                $success_url = $data['results']['successes'];
                $failure_url = $data['results']['failures'];
                $merchant_id = $data['merchant_id'];
                $uploader_id = $data['uploader_id'];
                $jobId = $data['id'];

                $this->db->query("UPDATE `". DB_PREFIX ."cedwish_job_status` SET success_url = '". $this->db->escape($success_url) ."', failure_url = '". $this->db->escape($failure_url) ."', merchant_id = '". $this->db->escape($merchant_id) ."', uploader_id = '". $this->db->escape($uploader_id) ."', data = '". json_encode($data) ."' WHERE job_id = '". $this->db->escape($jobId) ."' ");

                if(!empty($jobId)){
                    $bulkUpdateJobSuccess = $this->getBulkUpdateJobSuccess($jobId);
                    $bulkUpdateJobFailure = $this->getBulkUpdateJobFailure($jobId);

                    if($bulkUpdateJobSuccess && $bulkUpdateJobSuccess['success'] == 0)
                        $response = array('success' => false, 'message' => $bulkUpdateJobSuccess['message']);

                    if($bulkUpdateJobFailure && $bulkUpdateJobFailure['success'] == 1)
                        $response = array('success' => true, 'message' => $bulkUpdateJobFailure['data']);
                }

            } else {
                $response = array('success' => false, 'message'=> $request['message']);
            }
        } else {
            $response = array('success' => false, 'message'=> ' Required Param job_id Missing');
        }


        return $response;
    }

    public function getBulkUpdateJobSuccess($jobId)
    {
        $response = array();
        $path = 'variant/get-bulk-update-job-successes';
        $params = array(
            'job_id' => $jobId,
            'access_token' => $this->accessToken
        );

        $tokenResponse = $this->getRequest($path, $params);
        $request = $tokenResponse['response'];
//echo '<pre>'; print_r($tokenResponse); die;
        if(isset($request['code']) && $request['code'] == 0) {
            $data = $request['data'];
            $success = $data['successes'];

            $response = array('success' => true, 'data' => $success);
        } else {
            $response = array('success' => false, 'message' => $request['message']);
        }
        return $response;
    }

    public function getBulkUpdateJobFailure($jobId)
    {
        $response = array();
        $path = 'variant/get-bulk-update-job-failures';
        $params = array(
            'job_id' => $jobId,
            'access_token' => $this->accessToken
        );

        $tokenResponse = $this->getRequest($path, $params);
        $request = $tokenResponse['response'];

        if(isset($request['code']) && $request['code'] == 0) {
            $data = $request['data'];
            $errors = $data['errors'];

            $this->db->query("UPDATE `". DB_PREFIX ."cedwish_job_status` SET failure_data = '". $this->db->escape(json_encode($errors)) ."' WHERE job_id = '". $jobId ."' ");

            $response = array('success' => true, 'data' => $errors);
        } else {
            $response = array('success' => false, 'message' => $request['message']);
        }
        return $response;
    }

    public function getAccessToken($authorization_code, $redirect_uri)
    {
        $path = 'oauth/access_token';

        if (!$this->clientId || !$this->clientSecret || !$this->redirectUri) {
            return ['success' => false, 'message' => 'Please Fill Wish Credential(s).'];
        }

        $params = array(
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'code' => $authorization_code,
            'grant_type' => 'authorization_code',
            'redirect_uri' => $this->redirectUri
        );

        $tokenResponse = $this->postRequest($path, $params);
        $request = $tokenResponse['response'];

        if (isset($request['code']) && $request['code'] == 0) {
            $data = $request['data'];
            $store_id = $this->config->get('config_store_id');

            $this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '". $data['access_token'] ."' WHERE `code` = 'ced_wish' AND `key` = 'ced_wish_access_token' AND `store_id` = '". (int)$store_id ."' ");

            $this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '". $data['refresh_token'] ."' WHERE `code` = 'ced_wish' AND `key` = 'ced_wish_refresh_token' AND `store_id` = '". (int)$store_id ."' ");

            $query = $this->db->query("SELECT value FROM `" . DB_PREFIX . "setting` WHERE `code` = 'ced_wish' AND `key` = 'ced_wish_expiry_time' AND `store_id` = '". (int)$store_id ."' ");
            $result = $query->row;

            if(isset($result) && !empty($result['value']))
                $this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '". $data['expiry_time'] ."' WHERE `code` = 'ced_wish' AND `key` = 'ced_wish_expiry_time' AND `store_id` = '". (int)$store_id ."' ");
            else
                $this->db->query("INSERT INTO `" . DB_PREFIX . "setting` (`value`, `code`, `key`, `store_id`) VALUES ('". $data['expiry_time'] ."', 'ced_wish' , 'ced_wish_expiry_time' , '". (int)$store_id ."') ");

            // $this->cleanCache();
            return ['success' => true, 'data' => $data['access_token']];
        } else {
            return ['success' => false, 'message' => $request['message']];
        }

    }

    public function refreshToken()
    {
       $path = 'oauth/refresh_token';

        if (!$this->clientId || !$this->clientSecret || !$this->refreshToken) {
            return ['success' => false, 'message' => 'Please Fill Wish Credential(s).'];
        }
        $params = array(
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'refresh_token' => $this->refreshToken,
            'grant_type' => 'refresh_token'
        );
        $tokenResponse = $this->postRequest($path, $params);
        $request = $tokenResponse['response'];

        if(isset($request['code']) && $request['code'] == 0) {
            $data = $request['data'];
            $store_id = $this->config->get('config_store_id');

            $this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '". $data['access_token'] ."' WHERE `code` = 'ced_wish' AND `key` = 'ced_wish_access_token' AND `store_id` = '". (int)$store_id ."' ");

            $this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '". $data['refresh_token'] ."' WHERE `code` = 'ced_wish' AND `key` = 'ced_wish_refresh_token' AND `store_id` = '". (int)$store_id ."' ");

            $query = $this->db->query("SELECT value FROM `" . DB_PREFIX . "setting` WHERE `code` = 'ced_wish' AND `key` = 'ced_wish_expiry_time' AND `store_id` = '". (int)$store_id ."' ");
            $result = $query->row;

            if(isset($result) && !empty($result['value']))
                $this->db->query("UPDATE `" . DB_PREFIX . "setting` SET `value` = '". $data['expiry_time'] ."' WHERE `code` = 'ced_wish' AND `key` = 'ced_wish_expiry_time' AND `store_id` = '". (int)$store_id ."' ");
            else
                $this->db->query("INSERT INTO `" . DB_PREFIX . "setting` (`value`, `code`, `key`, `store_id`) VALUES ('". $data['expiry_time'] ."', 'ced_wish' , 'ced_wish_expiry_time' , '". (int)$store_id ."') ");

            // $this->cleanCache();
            return ['success' => true, 'data' => $data['access_token']];
        } else {
            return ['success' => false, 'message' => $request['message']];
        }

    }

    public function postRequest($endpoint, $post_params)
    {
        $url = $this->apiHost . $endpoint;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_params);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $this->createLog($url, $response, $post_params);
        return array(
            'status' => $status_code,
            'response' => json_decode($response, true)
        );
    }

    public function getRequest($endpoint, $get_params)
    {
        $url = $this->apiHost . $endpoint . $this->prepareQueryArguments($get_params);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_POST, false);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_ENCODING, '');
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        $response = curl_exec($ch);
        $status_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $this->createLog($url, $response);
        return array(
            'status' => $status_code,
            'response' => json_decode($response, true)
        );
    }

    public function prepareQueryArguments($args)
    {
        $query = [];
        $response = '';
        foreach ($args as $key => $value) {
            $query[] = $key.'='.$value;
        }
        if (!empty($query)) {
            $response = '?' .implode('&', $query);
        }
        return $response;
    }

    public function createLog($url, $response, $postParams = [], $force_log = true)
    {
        $data = json_decode($response, true);
        if ($this->config->get('ced_wish_enable_logging') || $force_log) {
            if (is_array($data) && $data['code'] != 0) {
                $log = "URL: ".$url.PHP_EOL.
                    "PostParam: ".json_encode($postParams).PHP_EOL.
                    "Response: ".$response.PHP_EOL;
                // $this->logger->error($log);
            }
        }
    }

    public function cleanCache()
    {
        $cacheType = array(
            'config',
        );
        foreach ($cacheType as $cache) {
            $this->cache->cleanType($cache);
        }
    }

    public function getExpiryTime()
    {
        $store_id = $this->config->get('config_store_id');

        $query = $this->db->query("SELECT value FROM `" . DB_PREFIX . "setting` WHERE `code` = 'ced_wish' AND `key` = 'ced_wish_expiry_time' AND `store_id` = '". (int)$store_id ."' ");
        $result = $query->row;
        return $result;
    }

    public function validateToken($token = null)
    { 
        $response = array();
        if ($token === null) {
            $token = $this->accessToken;
        }
        $expiry_time = $this->getExpiryTime();
        if (isset($expiry_time['value']) && time() < $expiry_time['value']) {
            $this->accessToken = $token;
        } else {
            $refresh_token = $this->refreshToken();
            if(isset($refresh_token) && $refresh_token['success']) 
                $this->accessToken = $refresh_token['data'];
            else 
               $response =  ['success' => false , 'message' => 'Access Token Expiry Limit Exceeded.'];
        }
        $response =  ['success' => true, 'data' => $this->accessToken];
        return $response;
    }

}

?>